package com.sportsdesk

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import com.sportsdesk.data.AuthRepository
import com.sportsdesk.data.SupabaseClientProvider
import com.sportsdesk.ui.auth.LoginRole
import com.sportsdesk.ui.auth.PasswordLoginScreen
import com.sportsdesk.ui.auth.ProfileRole
import com.sportsdesk.ui.auth.RolePickerScreen
import com.sportsdesk.ui.auth.StudentSignupScreen
import com.sportsdesk.ui.dashboard.StudentDashboard
import com.sportsdesk.ui.dashboard.TeacherDashboard
import com.sportsdesk.ui.theme.SportsDeskTheme
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.launch

enum class RootScreen { HOME, TEACHER_LOGIN, STUDENT_LOGIN, STUDENT_SIGNUP }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SportsDeskApp() }
    }
}

@Composable
private fun SportsDeskApp() {
    var darkMode by remember { mutableStateOf(false) }
    var screen by remember { mutableStateOf(RootScreen.HOME) }
    var signedInRole by remember { mutableStateOf<LoginRole?>(null) }
    var displayName by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    val authRepository = remember { AuthRepository() }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        runCatching {
            val session = SupabaseClientProvider.client.auth.currentSessionOrNull()
            if (session != null) {
                val userId = session.user?.id?.toString().orEmpty()
                val profile = SupabaseClientProvider.client.from("profiles").select {
                    filter { eq("id", userId) }
                }.decodeSingle<ProfileRole>()
                displayName = profile.full_name.orEmpty()
                signedInRole = when (profile.role.lowercase()) {
                    "teacher" -> LoginRole.TEACHER
                    "student" -> LoginRole.STUDENT
                    else -> null
                }
            }
        }
        loading = false
    }

    fun logout() {
        scope.launch {
            runCatching { authRepository.signOut() }
            signedInRole = null
            displayName = ""
            screen = RootScreen.HOME
        }
    }

    BackHandler(enabled = signedInRole == null && screen != RootScreen.HOME) {
        screen = when (screen) {
            RootScreen.TEACHER_LOGIN, RootScreen.STUDENT_LOGIN -> RootScreen.HOME
            RootScreen.STUDENT_SIGNUP -> RootScreen.STUDENT_LOGIN
            RootScreen.HOME -> RootScreen.HOME
        }
    }

    SportsDeskTheme(darkMode) {
        val view = LocalView.current
        val colors = MaterialTheme.colorScheme
        SideEffect {
            val activity = view.context as? ComponentActivity
            activity?.window?.let { window ->
                window.statusBarColor = colors.background.toArgb()
                window.navigationBarColor = colors.background.toArgb()
                WindowCompat.getInsetsController(window, view).apply {
                    isAppearanceLightStatusBars = !darkMode
                    isAppearanceLightNavigationBars = !darkMode
                }
            }
        }
        when {
            loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            signedInRole == LoginRole.TEACHER -> TeacherDashboard(
                name = displayName,
                darkMode = darkMode,
                onToggleTheme = { darkMode = !darkMode },
                onLogout = ::logout
            )
            signedInRole == LoginRole.STUDENT -> StudentDashboard(
                name = displayName,
                darkMode = darkMode,
                onToggleTheme = { darkMode = !darkMode },
                onLogout = ::logout
            )
            screen == RootScreen.HOME -> RolePickerScreen(
                darkMode = darkMode,
                onToggleTheme = { darkMode = !darkMode },
                onTeacher = { screen = RootScreen.TEACHER_LOGIN },
                onStudent = { screen = RootScreen.STUDENT_LOGIN }
            )
            screen == RootScreen.TEACHER_LOGIN -> PasswordLoginScreen(
                role = LoginRole.TEACHER,
                darkMode = darkMode,
                onToggleTheme = { darkMode = !darkMode },
                onBack = { screen = RootScreen.HOME },
                onSignedIn = { displayName = it; signedInRole = LoginRole.TEACHER }
            )
            screen == RootScreen.STUDENT_LOGIN -> PasswordLoginScreen(
                role = LoginRole.STUDENT,
                darkMode = darkMode,
                onToggleTheme = { darkMode = !darkMode },
                onBack = { screen = RootScreen.HOME },
                onSignedIn = { displayName = it; signedInRole = LoginRole.STUDENT },
                onStudentSignup = { screen = RootScreen.STUDENT_SIGNUP }
            )
            screen == RootScreen.STUDENT_SIGNUP -> StudentSignupScreen(
                darkMode = darkMode,
                onToggleTheme = { darkMode = !darkMode },
                onBack = { screen = RootScreen.STUDENT_LOGIN },
                onCreated = { screen = RootScreen.STUDENT_LOGIN }
            )
        }
    }
}
