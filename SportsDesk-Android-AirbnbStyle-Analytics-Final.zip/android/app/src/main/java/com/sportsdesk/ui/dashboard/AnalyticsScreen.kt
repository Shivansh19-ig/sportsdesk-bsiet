package com.sportsdesk.ui.dashboard

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sportsdesk.data.SportsRepository
import com.sportsdesk.data.model.AttendanceRecord
import com.sportsdesk.data.model.AttendanceSession
import com.sportsdesk.data.model.Sport
import com.sportsdesk.data.model.Student
import com.sportsdesk.ui.components.BsietLogo
import com.sportsdesk.ui.components.NeumorphicCard
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.roundToInt

private data class DaySummary(val date: LocalDate, val present: Int, val absent: Int) {
    val total get() = present + absent
    val percentage get() = if (total == 0) 0 else ((present * 100f) / total).roundToInt()
}

private data class StudentSummary(val student: Student, val present: Int, val total: Int) {
    val percentage get() = if (total == 0) 0 else ((present * 100f) / total).roundToInt()
}

@Composable
fun AnalyticsScreen(
    sport: Sport,
    repository: SportsRepository,
    darkMode: Boolean,
    onToggleTheme: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val monthFormatter = remember { DateTimeFormatter.ofPattern("MMMM yyyy", Locale.getDefault()) }
    val dateFormatter = remember { DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.getDefault()) }
    var month by remember { mutableStateOf(YearMonth.now()) }
    var selectedDate by remember { mutableStateOf<LocalDate?>(null) }
    var sessions by remember { mutableStateOf<List<AttendanceSession>>(emptyList()) }
    var records by remember { mutableStateOf<List<AttendanceRecord>>(emptyList()) }
    var students by remember { mutableStateOf<List<Student>>(emptyList()) }
    var search by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }

    LaunchedEffect(sport.id) {
        loading = true
        runCatching {
            val loadedSessions = repository.getAttendanceSessions(sport.id)
            sessions = loadedSessions
            records = repository.getAttendanceRecordsForSessions(loadedSessions.map { it.id })
            students = repository.getStudentsForSport(sport.id)
            val availableDates = loadedSessions.map { LocalDate.parse(it.attendance_date) }
            selectedDate = availableDates.firstOrNull()
            availableDates.firstOrNull()?.let { month = YearMonth.from(it) }
        }.onFailure {
            sessions = emptyList(); records = emptyList(); students = emptyList(); selectedDate = null
            error = "Could not load analytics right now."
        }
        loading = false
    }

    val sessionByDate = remember(sessions) { sessions.associateBy { LocalDate.parse(it.attendance_date) } }
    val recordsBySession = remember(records) { records.groupBy { it.session_id } }
    val daySummaries = remember(sessionByDate, recordsBySession) {
        sessionByDate.mapNotNull { (date, session) ->
            val rs = recordsBySession[session.id].orEmpty()
            if (rs.isEmpty()) null else DaySummary(date, rs.count { it.status.equals("present", true) }, rs.count { it.status.equals("absent", true) })
        }
    }
    val summaryByDate = remember(daySummaries) { daySummaries.associateBy { it.date } }

    val totalPresent = records.count { it.status.equals("present", true) }
    val totalAbsent = records.count { it.status.equals("absent", true) }
    val totalMarked = totalPresent + totalAbsent
    val overall = if (totalMarked == 0) 0 else ((totalPresent * 100f) / totalMarked).roundToInt()

    val studentSummaries = remember(records, students) {
        val grouped = records.groupBy { it.student_id }
        students.map { student ->
            val rs = grouped[student.id].orEmpty()
            StudentSummary(student, rs.count { it.status.equals("present", true) }, rs.size)
        }.filter { it.total > 0 }
            .sortedWith(compareBy<StudentSummary> { it.student.roll_number.toIntOrNull() ?: Int.MAX_VALUE }.thenBy { it.student.roll_number })
    }
    val filteredStudents = studentSummaries.filter { summary ->
        search.isBlank() || summary.student.full_name.contains(search, true) || summary.student.roll_number.contains(search, true)
    }

    val selectedRecords = selectedDate?.let { date -> sessionByDate[date]?.let { recordsBySession[it.id].orEmpty() } }.orEmpty()
    val selectedStudentMap = students.associateBy { it.id }
    val selectedPresent = selectedRecords.filter { it.status.equals("present", true) }
        .sortedWith(compareBy<AttendanceRecord> { selectedStudentMap[it.student_id]?.roll_number?.toIntOrNull() ?: Int.MAX_VALUE }.thenBy { selectedStudentMap[it.student_id]?.roll_number.orEmpty() })
    val selectedAbsent = selectedRecords.filter { it.status.equals("absent", true) }
        .sortedWith(compareBy<AttendanceRecord> { selectedStudentMap[it.student_id]?.roll_number?.toIntOrNull() ?: Int.MAX_VALUE }.thenBy { selectedStudentMap[it.student_id]?.roll_number.orEmpty() })

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
                BsietLogo(Modifier.weight(1f))
                IconButton(onClick = onToggleTheme) { Icon(if (darkMode) Icons.Default.LightMode else Icons.Default.DarkMode, "Toggle theme") }
            }

            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text("Analytics", style = MaterialTheme.typography.headlineLarge)
                    Text("${sport.emoji} ${sport.name} • calendar + student insights", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        AnalyticStat(overall.toString() + "%", "Overall", Modifier.weight(1f))
                        AnalyticStat(daySummaries.size.toString(), "Sessions", Modifier.weight(1f))
                        AnalyticStat(students.size.toString(), "Students", Modifier.weight(1f))
                    }
                }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        AnalyticStat(totalPresent.toString(), "Present", Modifier.weight(1f))
                        AnalyticStat(totalAbsent.toString(), "Absent", Modifier.weight(1f))
                        AnalyticStat(totalMarked.toString(), "Marks", Modifier.weight(1f))
                    }
                }
                if (error.isNotBlank()) item { Text(error, color = MaterialTheme.colorScheme.error) }
                if (loading) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }

                item {
                    NeumorphicCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(month.format(monthFormatter), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                IconButton(onClick = { month = month.minusMonths(1) }) { Icon(Icons.Default.ChevronLeft, "Previous month") }
                                IconButton(onClick = { month = month.plusMonths(1) }) { Icon(Icons.Default.ChevronRight, "Next month") }
                            }
                            CalendarGrid(month, summaryByDate, selectedDate) { selectedDate = it }
                        }
                    }
                }

                item {
                    NeumorphicCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.EventAvailable, null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(8.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(selectedDate?.format(dateFormatter) ?: "Select a date", fontWeight = FontWeight.SemiBold)
                                    Text("${selectedPresent.size} present • ${selectedAbsent.size} absent", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            if (selectedDate != null && selectedRecords.isNotEmpty()) {
                                Text("Present", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                selectedPresent.forEach { record ->
                                    CompactStudentLine(selectedStudentMap[record.student_id], true)
                                }
                                Spacer(Modifier.height(4.dp))
                                Text("Absent", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                selectedAbsent.forEach { record ->
                                    CompactStudentLine(selectedStudentMap[record.student_id], false)
                                }
                            } else {
                                Text("No saved attendance data for this date.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }

                item {
                    Text("Student attendance", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                }
                item {
                    OutlinedTextField(
                        value = search,
                        onValueChange = { search = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        leadingIcon = { Icon(Icons.Default.Search, null) },
                        placeholder = { Text("Search name or roll number") }
                    )
                }
                items(filteredStudents, key = { it.student.id }) { summary ->
                    NeumorphicCard(Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(summary.student.full_name, fontWeight = FontWeight.SemiBold)
                                Text("${summary.student.roll_number} • ${summary.present}/${summary.total} present", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("${summary.percentage}%", fontWeight = FontWeight.SemiBold)
                                LinearProgressIndicator(
                                    progress = summary.percentage / 100f,
                                    modifier = Modifier.width(72.dp).padding(top = 5.dp)
                                )
                            }
                        }
                    }
                }
                if (!loading && filteredStudents.isEmpty()) {
                    item { Text("No student attendance data matches this search.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
            }
        }
    }
}

@Composable
private fun CalendarGrid(month: YearMonth, summaries: Map<LocalDate, DaySummary>, selectedDate: LocalDate?, onSelect: (LocalDate) -> Unit) {
    val labels = listOf("S", "M", "T", "W", "T", "F", "S")
    val first = month.atDay(1)
    val offset = first.dayOfWeek.value % 7
    val days = (0 until offset).map { null } + (1..month.lengthOfMonth()).map { month.atDay(it) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth()) {
            labels.forEach { label -> Text(label, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        }
        days.chunked(7).forEach { week ->
            Row(Modifier.fillMaxWidth()) {
                week.forEach { date ->
                    Box(Modifier.weight(1f).aspectRatio(1f).padding(2.dp), contentAlignment = Alignment.Center) {
                        if (date != null) {
                            val summary = summaries[date]
                            val selected = date == selectedDate
                            Column(
                                Modifier.fillMaxSize().clip(CircleShape).background(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant).clickable { onSelect(date) },
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(date.dayOfMonth.toString(), color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.labelSmall)
                                if (summary != null) {
                                    Text("${summary.present}/${summary.total}", color = if (selected) MaterialTheme.colorScheme.onPrimary.copy(.9f) else MaterialTheme.colorScheme.secondary, style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
                repeat(7 - week.size) { Box(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun CompactStudentLine(student: Student?, present: Boolean) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(student?.full_name ?: "Unknown student", style = MaterialTheme.typography.bodyMedium)
            Text(student?.roll_number.orEmpty(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(if (present) "Present" else "Absent", color = if (present) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
private fun AnalyticStat(value: String, label: String, modifier: Modifier) {
    NeumorphicCard(modifier) { Column(Modifier.padding(14.dp)) { Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold); Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.labelSmall) } }
}
