package com.sportsdesk.ui.dashboard

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sportsdesk.data.SportsRepository
import com.sportsdesk.data.model.Sport
import com.sportsdesk.ui.components.BsietLogo
import com.sportsdesk.ui.components.NeumorphicCard
import kotlinx.coroutines.launch

@Composable
fun SportSelectionScreen(
    title: String,
    subtitle: String,
    sports: List<Sport>,
    selectedIds: Set<String>,
    onBack: () -> Unit,
    onSave: (Set<String>) -> Unit,
    repository: SportsRepository,
    studentId: String,
    darkMode: Boolean,
    onToggleTheme: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var selection by remember(selectedIds) { mutableStateOf(selectedIds) }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    BackHandler(onBack = onBack)

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
                BsietLogo(Modifier.weight(1f))
                IconButton(onClick = onToggleTheme) { Icon(if (darkMode) Icons.Default.LightMode else Icons.Default.DarkMode, "Toggle theme") }
            }
            Column(Modifier.padding(horizontal = 20.dp)) {
                Text(title, style = MaterialTheme.typography.headlineLarge)
                Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(12.dp))
                Text("${selection.size} sports selected", fontWeight = FontWeight.SemiBold)
                if (error.isNotBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Text(error, color = MaterialTheme.colorScheme.error)
                }
            }
            LazyColumn(
                Modifier.weight(1f),
                contentPadding = PaddingValues(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(sports, key = { it.id }) { sport ->
                    val checked = sport.id in selection
                    NeumorphicCard(Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = checked, onCheckedChange = { selection = if (it) selection + sport.id else selection - sport.id })
                            Text(sport.emoji, style = MaterialTheme.typography.headlineSmall)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(sport.name, fontWeight = FontWeight.SemiBold)
                                Text("Available for enrollment", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (checked) Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
            Button(
                enabled = !saving && selection.isNotEmpty(),
                onClick = {
                    scope.launch {
                        saving = true
                        error = ""
                        runCatching { repository.replaceStudentSports(studentId, selection) }
                            .onSuccess { onSave(selection) }
                            .onFailure { error = "Could not save sports. Please try again." }
                        saving = false
                    }
                },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
                shape = RoundedCornerShape(999.dp)
            ) { Text(if (saving) "Saving…" else "Save sports") }
        }
    }
}
