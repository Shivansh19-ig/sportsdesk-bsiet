package com.sportsdesk.data.model

import kotlinx.serialization.Serializable
import kotlinx.serialization.SerialName

@Serializable
data class Sport(
    val id: String,
    val name: String,
    val emoji: String = "🏅",
    val active: Boolean = true
)

@Serializable
data class Student(
    val id: String,
    val roll_number: String,
    val full_name: String,
    val class_name: String? = null,
    val division: String? = null,
    val active: Boolean = true,
    val auth_user_id: String? = null
)

@Serializable
data class StudentCreate(
    val roll_number: String,
    val full_name: String,
    val class_name: String,
    val division: String,
    val auth_user_id: String,
    val active: Boolean = true
)

@Serializable
data class SportCreate(
    val name: String,
    val emoji: String,
    val active: Boolean = true
)

@Serializable
data class SportMembership(
    val id: String,
    val sport_id: String,
    val student_id: String
)

@Serializable
data class SportMembershipCreate(
    val sport_id: String,
    val student_id: String
)

@Serializable
data class AttendanceSession(
    val id: String,
    val sport_id: String,
    val attendance_date: String
)

@Serializable
data class AttendanceSessionCreate(
    val sport_id: String,
    val attendance_date: String
)

@Serializable
data class AttendanceRecord(
    val id: String,
    val session_id: String,
    val student_id: String,
    val status: String,
    val marked_at: String? = null
)

@Serializable
data class AttendanceRecordCreate(
    val session_id: String,
    val student_id: String,
    val status: String
)

@Serializable
data class SaveAttendanceRpcParams(
    @SerialName("p_sport_id") val pSportId: String,
    @SerialName("p_attendance_date") val pAttendanceDate: String,
    @SerialName("p_present_student_ids") val pPresentStudentIds: List<String>,
    @SerialName("p_all_student_ids") val pAllStudentIds: List<String>
)

@Serializable
data class StudentSetupRpcParams(
    @SerialName("p_roll_number") val pRollNumber: String,
    @SerialName("p_full_name") val pFullName: String,
    @SerialName("p_class_name") val pClassName: String,
    @SerialName("p_division") val pDivision: String,
    @SerialName("p_sport_ids") val pSportIds: List<String>
)

@Serializable
data class ReplaceSportsRpcParams(
    @SerialName("p_student_id") val pStudentId: String,
    @SerialName("p_sport_ids") val pSportIds: List<String>
)

enum class AttendanceStatus { PRESENT, ABSENT }
