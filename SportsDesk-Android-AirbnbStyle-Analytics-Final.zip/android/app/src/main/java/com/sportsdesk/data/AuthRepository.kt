package com.sportsdesk.data

import io.github.jan.supabase.auth.providers.Email
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

class AuthRepository {
    private val auth = SupabaseClientProvider.client.auth

    suspend fun signIn(email: String, password: String) {
        auth.signInWith(Email) {
            this.email = email
            this.password = password
        }
    }

    suspend fun signUpStudent(email: String, password: String, fullName: String) {
        auth.signUpWith(Email) {
            this.email = email
            this.password = password
            data = buildJsonObject { put("full_name", fullName) }
        }
    }

    suspend fun signOut() = auth.signOut()

    fun currentUserId(): String? = auth.currentSessionOrNull()?.user?.id?.toString()
}
