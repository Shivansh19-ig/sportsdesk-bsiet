package com.sportsdesk.ui.dashboard

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sportsdesk.data.SportsRepository
import com.sportsdesk.data.model.Sport
import com.sportsdesk.data.model.Student
import com.sportsdesk.ui.components.BsietLogo
import com.sportsdesk.ui.components.NeumorphicCard
import kotlinx.coroutines.launch

private enum class TeacherChild { NONE, ATTENDANCE, RECORDS, ANALYTICS }

@Composable
fun TeacherDashboard(
    name: String,
    darkMode: Boolean,
    onToggleTheme: () -> Unit,
    onLogout: () -> Unit
) {
    val repo = remember { SportsRepository() }
    val scope = rememberCoroutineScope()
    var sports by remember { mutableStateOf<List<Sport>>(emptyList()) }
    var students by remember { mutableStateOf<List<Student>>(emptyList()) }
    var selectedSport by remember { mutableStateOf<Sport?>(null) }
    var child by remember { mutableStateOf(TeacherChild.NONE) }
    var addDialog by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    var profileMenu by remember { mutableStateOf(false) }

    suspend fun refresh() {
        loading = true
        error = ""
        runCatching {
            sports = repo.getSports()
            students = repo.getStudents().filter { it.active }
        }.onFailure { error = "Could not refresh the dashboard." }
        loading = false
    }

    LaunchedEffect(Unit) { refresh() }

    if (selectedSport != null && child == TeacherChild.ATTENDANCE) {
        AttendanceScreen(
            sport = selectedSport!!,
            repository = repo,
            darkMode = darkMode,
            onToggleTheme = onToggleTheme,
            onBack = { child = TeacherChild.NONE; selectedSport = null },
            onViewRecords = { child = TeacherChild.RECORDS },
            onViewAnalytics = { child = TeacherChild.ANALYTICS }
        )
        return
    }

    if (selectedSport != null && child == TeacherChild.RECORDS) {
        AttendanceRecordsScreen(
            sport = selectedSport!!,
            repository = repo,
            darkMode = darkMode,
            onToggleTheme = onToggleTheme,
            onBack = { child = TeacherChild.ATTENDANCE }
        )
        return
    }

    if (selectedSport != null && child == TeacherChild.ANALYTICS) {
        AnalyticsScreen(
            sport = selectedSport!!,
            repository = repo,
            darkMode = darkMode,
            onToggleTheme = onToggleTheme,
            onBack = { child = TeacherChild.ATTENDANCE }
        )
        return
    }

    BackHandler(enabled = selectedSport != null) {
        selectedSport = null
        child = TeacherChild.NONE
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BsietLogo(Modifier.weight(1f))
                Box {
                    IconButton(onClick = { profileMenu = !profileMenu }) {
                        Icon(Icons.Default.Person, "Profile")
                    }
                    DropdownMenu(expanded = profileMenu, onDismissRequest = { profileMenu = false }) {
                        DropdownMenuItem(
                            text = { Text("$name • Teacher") },
                            onClick = { profileMenu = false },
                            leadingIcon = { Icon(Icons.Default.Person, null) }
                        )
                        DropdownMenuItem(
                            text = { Text(if (darkMode) "Light mode" else "Dark mode") },
                            onClick = { profileMenu = false; onToggleTheme() },
                            leadingIcon = { Icon(if (darkMode) Icons.Default.LightMode else Icons.Default.DarkMode, null) }
                        )
                        DropdownMenuItem(
                            text = { Text("Log out") },
                            onClick = { profileMenu = false; onLogout() },
                            leadingIcon = { Icon(Icons.Default.Logout, null) }
                        )
                    }
                }
            }

            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Text("Welcome back,", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(name.ifBlank { "Coach" }, style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.SemiBold)
                    Text("Your sports desk at a glance.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                item {
                    NeumorphicCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    Modifier.size(48.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.primaryContainer),
                                    contentAlignment = Alignment.Center
                                ) { Icon(Icons.Default.EventAvailable, null, tint = MaterialTheme.colorScheme.primary) }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("Attendance command center", fontWeight = FontWeight.SemiBold)
                                    Text("Mark, review and understand attendance by sport.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            Button(
                                onClick = { sports.firstOrNull()?.let { selectedSport = it; child = TeacherChild.ATTENDANCE } },
                                enabled = sports.isNotEmpty(),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(999.dp)
                            ) { Text("Take attendance") }
                        }
                    }
                }

                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        DashboardStat(students.size.toString(), "Active students", Modifier.weight(1f), Icons.Default.Person)
                        DashboardStat(sports.size.toString(), "Active sports", Modifier.weight(1f), Icons.Default.SportsSoccer)
                        DashboardStat("${students.size}", "Roster size", Modifier.weight(1f), Icons.Default.CalendarMonth)
                    }
                }

                item {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Your sports", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                            Text("Live from Supabase", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        FilledTonalButton(onClick = { addDialog = true }, shape = RoundedCornerShape(999.dp)) {
                            Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Add sport")
                        }
                    }
                }

                if (loading) {
                    item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
                }
                if (error.isNotBlank()) item { Text(error, color = MaterialTheme.colorScheme.error) }
                if (sports.isEmpty() && !loading) {
                    item { EmptyState("No sports yet", "Add a sport to start building your attendance workspace.") }
                } else {
                    items(sports, key = { it.id }) { sport ->
                        NeumorphicCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(sport.emoji, style = MaterialTheme.typography.headlineMedium)
                                    Spacer(Modifier.width(12.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(sport.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                                        Text("Attendance workspace", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = { selectedSport = sport; child = TeacherChild.ATTENDANCE },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(999.dp)
                                    ) { Text("Attendance") }
                                    OutlinedButton(
                                        onClick = { selectedSport = sport; child = TeacherChild.RECORDS },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(999.dp)
                                    ) { Text("Records") }
                                }
                                OutlinedButton(
                                    onClick = { selectedSport = sport; child = TeacherChild.ANALYTICS },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(999.dp)
                                ) {
                                    Icon(Icons.Default.Analytics, null); Spacer(Modifier.width(8.dp)); Text("Open analytics & calendar")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (addDialog) {
        AddSportDialog(
            onDismiss = { addDialog = false },
            onAdd = { sportName, emoji ->
                scope.launch {
                    runCatching { repo.addSport(sportName, emoji) }
                        .onSuccess { addDialog = false; refresh() }
                        .onFailure { error = "Could not add that sport." }
                }
            }
        )
    }
}

@Composable
fun StudentDashboard(
    name: String,
    darkMode: Boolean,
    onToggleTheme: () -> Unit,
    onLogout: () -> Unit
) {
    val repo = remember { SportsRepository() }
    val scope = rememberCoroutineScope()
    var sports by remember { mutableStateOf<List<Sport>>(emptyList()) }
    var selectedIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    var student by remember { mutableStateOf<Student?>(null) }
    var chooseSports by remember { mutableStateOf(false) }

    suspend fun refresh() {
        val userId = com.sportsdesk.data.SupabaseClientProvider.client.auth.currentSessionOrNull()?.user?.id?.toString() ?: return
        sports = runCatching { repo.getSports() }.getOrDefault(emptyList())
        student = repo.getStudentByAuthId(userId)
        if (student != null) selectedIds = repo.getSelectedSportIds(student!!.id)
    }

    LaunchedEffect(Unit) { refresh() }

    if (student == null) {
        StudentSetupScreen(
            name = name,
            sports = sports,
            repository = repo,
            darkMode = darkMode,
            onToggleTheme = onToggleTheme,
            onComplete = {
                scope.launch {
                    refreshFromStudent(
                        studentSetter = { student = it },
                        selectionSetter = { selectedIds = it },
                        repo = repo
                    )
                }
            },
            onLogout = onLogout
        )
        return
    }

    if (chooseSports) {
        SportSelectionScreen(
            title = "Choose your sports",
            subtitle = "You can participate in more than one sport.",
            sports = sports,
            selectedIds = selectedIds,
            onBack = { chooseSports = false },
            onSave = { newSelection -> selectedIds = newSelection; chooseSports = false },
            repository = repo,
            studentId = student!!.id,
            darkMode = darkMode,
            onToggleTheme = onToggleTheme
        )
        return
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        LazyColumn(
            Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    BsietLogo(Modifier.weight(1f))
                    IconButton(onClick = onToggleTheme) { Icon(if (darkMode) Icons.Default.LightMode else Icons.Default.DarkMode, "Toggle theme") }
                    IconButton(onClick = onLogout) { Icon(Icons.Default.Logout, "Log out") }
                }
            }
            item {
                Text("Hello, $name", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.SemiBold)
                Text("Your SportsDesk profile", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            item {
                NeumorphicCard(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(54.dp).clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Default.Person, null, tint = MaterialTheme.colorScheme.primary) }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(student!!.full_name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                            Text("Roll no. ${student!!.roll_number}")
                            Text("${student!!.class_name.orEmpty()} • ${student!!.division.orEmpty()}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("My sports", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                        Text("${selectedIds.size} selected", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    FilledTonalButton(onClick = { chooseSports = true }, shape = RoundedCornerShape(999.dp)) { Text("Edit") }
                }
            }
            val mySports = sports.filter { it.id in selectedIds }
            if (mySports.isEmpty()) {
                item { EmptyState("No sports selected", "Choose one or more sports to keep your profile connected to training.") }
            } else {
                items(mySports, key = { it.id }) { sport ->
                    NeumorphicCard(Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(sport.emoji, style = MaterialTheme.typography.headlineSmall)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(sport.name, fontWeight = FontWeight.SemiBold)
                                Text("Attendance is recorded by your coach.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }
}

private suspend fun refreshFromStudent(
    studentSetter: (Student?) -> Unit,
    selectionSetter: (Set<String>) -> Unit,
    repo: SportsRepository
) {
    val uid = com.sportsdesk.data.SupabaseClientProvider.client.auth.currentSessionOrNull()?.user?.id?.toString().orEmpty()
    val student = repo.getStudentByAuthId(uid)
    studentSetter(student)
    if (student != null) selectionSetter(repo.getSelectedSportIds(student.id))
}

@Composable
private fun DashboardStat(value: String, label: String, modifier: Modifier, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    NeumorphicCard(modifier) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun EmptyState(title: String, body: String) {
    NeumorphicCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(body, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
