package com.sportsdesk.ui.dashboard

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sportsdesk.data.SportsRepository
import com.sportsdesk.data.model.Student
import com.sportsdesk.data.model.Sport
import com.sportsdesk.ui.components.BsietLogo
import com.sportsdesk.ui.components.NeumorphicCard
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun AttendanceScreen(
    sport: Sport,
    repository: SportsRepository,
    darkMode: Boolean,
    onToggleTheme: () -> Unit,
    onBack: () -> Unit,
    onViewRecords: () -> Unit,
    onViewAnalytics: () -> Unit
) {
    BackHandler(onBack = onBack)
    val scope = rememberCoroutineScope()
    val formatter = remember { DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.getDefault()) }
    var attendanceDate by remember { mutableStateOf(LocalDate.now()) }
    var students by remember { mutableStateOf<List<Student>>(emptyList()) }
    var present by remember { mutableStateOf<Set<String>>(emptySet()) }
    var search by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var saving by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var showCalendar by remember { mutableStateOf(false) }

    suspend fun refresh() {
        loading = true
        message = ""
        runCatching {
            val roster = repository.getStudentsForSport(sport.id)
            val session = repository.getAttendanceSession(sport.id, attendanceDate.toString())
            val saved = if (session == null) emptyList() else repository.getAttendanceRecords(session.id)
            students = roster
            present = if (saved.isEmpty()) roster.map { it.id }.toSet() else saved.filter { it.status.equals("present", true) }.map { it.student_id }.toSet()
        }.onFailure {
            students = emptyList()
            present = emptySet()
            message = "Could not load this attendance sheet."
        }
        loading = false
    }

    LaunchedEffect(sport.id, attendanceDate) { refresh() }

    val visibleStudents = students.filter {
        search.isBlank() || it.full_name.contains(search, true) || it.roll_number.contains(search, true)
    }
    val absentCount = (students.size - present.intersect(students.map { it.id }.toSet()).size).coerceAtLeast(0)

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
                BsietLogo(Modifier.weight(1f))
                IconButton(onClick = onToggleTheme) { Icon(if (darkMode) Icons.Default.LightMode else Icons.Default.DarkMode, "Toggle theme") }
            }

            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text("Take attendance", style = MaterialTheme.typography.headlineLarge)
                    Text("${sport.emoji} ${sport.name}", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                item {
                    OutlinedButton(
                        onClick = { showCalendar = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Default.CalendarMonth, null)
                        Spacer(Modifier.width(8.dp))
                        Text("${attendanceDate.format(formatter)} • ${if (attendanceDate == LocalDate.now()) "Today" else "Saved date"}")
                    }
                }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        AttendanceStat(present.intersect(students.map { it.id }.toSet()).size.toString(), "Present", true, Modifier.weight(1f))
                        AttendanceStat(absentCount.toString(), "Absent", false, Modifier.weight(1f))
                        AttendanceStat(students.size.toString(), "Total", null, Modifier.weight(1f))
                    }
                }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { present = students.map { it.id }.toSet() },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(999.dp)
                        ) { Icon(Icons.Default.SelectAll, null); Spacer(Modifier.width(6.dp)); Text("All present") }
                        OutlinedButton(
                            onClick = { present = emptySet() },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(999.dp)
                        ) { Text("All absent") }
                    }
                }
                item {
                    OutlinedTextField(
                        value = search,
                        onValueChange = { search = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        leadingIcon = { Icon(Icons.Default.Search, null) },
                        placeholder = { Text("Search name or roll number") }
                    )
                }
                if (loading) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
                if (message.isNotBlank()) item { Text(message, color = MaterialTheme.colorScheme.error) }
                items(visibleStudents, key = { it.id }) { student ->
                    val isPresent = student.id in present
                    NeumorphicCard(Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(student.full_name, fontWeight = FontWeight.SemiBold)
                                Text("${student.roll_number} • ${student.class_name.orEmpty()} ${student.division.orEmpty()}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            AssistChip(
                                onClick = { present = if (isPresent) present - student.id else present + student.id },
                                label = { Text(if (isPresent) "Present" else "Absent") },
                                leadingIcon = { if (isPresent) Icon(Icons.Default.CheckCircle, null) }
                            )
                        }
                    }
                }
                if (students.isEmpty() && !loading) {
                    item { Text("No students are enrolled in ${sport.name} yet.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = onViewRecords, modifier = Modifier.weight(1f), shape = RoundedCornerShape(999.dp)) { Text("Records") }
                        OutlinedButton(onClick = onViewAnalytics, modifier = Modifier.weight(1f), shape = RoundedCornerShape(999.dp)) { Text("Analytics") }
                    }
                }
                item {
                    Button(
                        enabled = !saving && students.isNotEmpty(),
                        onClick = {
                            scope.launch {
                                saving = true
                                message = ""
                                runCatching {
                                    repository.saveAttendance(
                                        sportId = sport.id,
                                        date = attendanceDate.toString(),
                                        presentStudentIds = present,
                                        allStudentIds = students.map { it.id }
                                    )
                                }.onSuccess {
                                    message = "Attendance saved for ${attendanceDate.format(formatter)}."
                                }.onFailure {
                                    message = "We couldn't save this attendance sheet. Please try again."
                                }
                                saving = false
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(999.dp)
                    ) {
                        Icon(Icons.Default.EventAvailable, null); Spacer(Modifier.width(8.dp)); Text(if (saving) "Saving…" else "Save attendance")
                    }
                }
            }
        }
    }

    if (showCalendar) {
        val state = rememberDatePickerState(
            initialSelectedDateMillis = attendanceDate.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        )
        DatePickerDialog(
            onDismissRequest = { showCalendar = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { millis ->
                        val selected = Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault()).toLocalDate()
                        if (selected.isAfter(LocalDate.now())) {
                            message = "Attendance cannot be recorded for a future date."
                        } else {
                            attendanceDate = selected
                            showCalendar = false
                        }
                    }
                }) { Text("Apply") }
            },
            dismissButton = { TextButton(onClick = { showCalendar = false }) { Text("Cancel") } }
        ) { DatePicker(state = state) }
    }
}

@Composable
private fun AttendanceStat(value: String, label: String, positive: Boolean?, modifier: Modifier) {
    NeumorphicCard(modifier) {
        Column(Modifier.padding(14.dp)) {
            Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Text(label, color = when (positive) {
                true -> MaterialTheme.colorScheme.secondary
                false -> MaterialTheme.colorScheme.error
                null -> MaterialTheme.colorScheme.onSurfaceVariant
            })
        }
    }
}

@Composable
fun AddSportDialog(onDismiss: () -> Unit, onAdd: (String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var emoji by remember { mutableStateOf("🏅") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add sport") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(name, { name = it.take(40) }, label = { Text("Sport name") }, singleLine = true, shape = RoundedCornerShape(14.dp))
                OutlinedTextField(emoji, { emoji = it.take(2) }, label = { Text("Emoji") }, singleLine = true, shape = RoundedCornerShape(14.dp))
            }
        },
        confirmButton = { Button(enabled = name.trim().length >= 2, onClick = { onAdd(name.trim(), emoji) }, shape = RoundedCornerShape(999.dp)) { Text("Add sport") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
