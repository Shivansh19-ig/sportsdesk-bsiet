package com.sportsdesk.ui.dashboard

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sportsdesk.data.SportsRepository
import com.sportsdesk.data.model.AttendanceRecord
import com.sportsdesk.data.model.AttendanceSession
import com.sportsdesk.data.model.Sport
import com.sportsdesk.data.model.Student
import com.sportsdesk.ui.components.BsietLogo
import com.sportsdesk.ui.components.NeumorphicCard
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

enum class AttendanceFilter { ALL, PRESENT, ABSENT }

@Composable
fun AttendanceRecordsScreen(
    sport: Sport,
    repository: SportsRepository,
    darkMode: Boolean,
    onToggleTheme: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val formatter = remember { DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.getDefault()) }
    var sessions by remember { mutableStateOf<List<AttendanceSession>>(emptyList()) }
    var selectedSession by remember { mutableStateOf<AttendanceSession?>(null) }
    var records by remember { mutableStateOf<List<AttendanceRecord>>(emptyList()) }
    var students by remember { mutableStateOf<Map<String, Student>>(emptyMap()) }
    var loading by remember { mutableStateOf(true) }
    var loadingRecords by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(AttendanceFilter.ALL) }

    LaunchedEffect(sport.id) {
        loading = true
        runCatching { repository.getAttendanceSessions(sport.id) }
            .onSuccess { list -> sessions = list; selectedSession = list.firstOrNull() }
            .onFailure { error = "Could not load attendance history." }
        loading = false
    }

    LaunchedEffect(selectedSession?.id) {
        val session = selectedSession ?: return@LaunchedEffect
        loadingRecords = true
        runCatching {
            val loadedRecords = repository.getAttendanceRecords(session.id)
            val loadedStudents = repository.getStudentsByIds(loadedRecords.map { it.student_id }.distinct()).associateBy { it.id }
            loadedRecords to loadedStudents
        }.onSuccess { (loadedRecords, loadedStudents) ->
            records = loadedRecords
            students = loadedStudents
            error = ""
        }.onFailure { error = "Could not load this attendance record." }
        loadingRecords = false
    }

    val filtered = records.filter { record ->
        when (filter) {
            AttendanceFilter.ALL -> true
            AttendanceFilter.PRESENT -> record.status.equals("present", true)
            AttendanceFilter.ABSENT -> record.status.equals("absent", true)
        }
    }.filter { record ->
        val student = students[record.student_id]
        search.isBlank() || student?.full_name?.contains(search, true) == true || student?.roll_number?.contains(search, true) == true
    }.sortedWith(
        compareBy<AttendanceRecord> { students[it.student_id]?.roll_number?.toIntOrNull() ?: Int.MAX_VALUE }
            .thenBy { students[it.student_id]?.roll_number.orEmpty() }
            .thenBy { students[it.student_id]?.full_name?.lowercase().orEmpty() }
    )

    val presentCount = records.count { it.status.equals("present", true) }
    val absentCount = records.count { it.status.equals("absent", true) }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
                BsietLogo(Modifier.weight(1f))
                IconButton(onClick = onToggleTheme) { Icon(if (darkMode) Icons.Default.LightMode else Icons.Default.DarkMode, "Toggle theme") }
            }

            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text("Attendance records", style = MaterialTheme.typography.headlineLarge)
                    Text("${sport.emoji} ${sport.name}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                item {
                    Text("Sessions", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    if (sessions.isNotEmpty()) {
                        LazyColumn(Modifier.fillMaxWidth().heightIn(max = 190.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(sessions, key = { it.id }) { session ->
                                val selected = session.id == selectedSession?.id
                                FilterChip(
                                    selected = selected,
                                    onClick = { selectedSession = session },
                                    label = {
                                        Text(runCatching { LocalDate.parse(session.attendance_date).format(formatter) }.getOrDefault(session.attendance_date))
                                    },
                                    leadingIcon = { Icon(Icons.Default.EventAvailable, null) }
                                )
                            }
                        }
                    } else if (!loading) {
                        NeumorphicCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(18.dp)) {
                                Text("No attendance has been saved yet.", fontWeight = FontWeight.SemiBold)
                                Text("Save a session from Take attendance and it will appear here in chronological history.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
                if (loading) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
                if (selectedSession != null) {
                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            RecordCount(presentCount.toString(), "Present", Modifier.weight(1f))
                            RecordCount(absentCount.toString(), "Absent", Modifier.weight(1f))
                            RecordCount(records.size.toString(), "Total", Modifier.weight(1f))
                        }
                    }
                    item {
                        OutlinedTextField(
                            value = search,
                            onValueChange = { search = it },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            leadingIcon = { Icon(Icons.Default.Search, null) },
                            placeholder = { Text("Search name or roll number") }
                        )
                    }
                    item {
                        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                            listOf(AttendanceFilter.ALL, AttendanceFilter.PRESENT, AttendanceFilter.ABSENT).forEachIndexed { index, item ->
                                SegmentedButton(
                                    selected = filter == item,
                                    onClick = { filter = item },
                                    shape = SegmentedButtonDefaults.itemShape(index = index, count = 3)
                                ) { Text(item.name.lowercase().replaceFirstChar(Char::uppercaseChar)) }
                            }
                        }
                    }
                    if (loadingRecords) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
                    if (error.isNotBlank()) item { Text(error, color = MaterialTheme.colorScheme.error) }

                    val presentRecords = filtered.filter { it.status.equals("present", true) }
                    val absentRecords = filtered.filter { it.status.equals("absent", true) }
                    if (filter == AttendanceFilter.ALL) {
                        item { RecordSectionTitle("Present", presentRecords.size, true) }
                        items(presentRecords, key = { it.id }) { RecordRow(it, students[it.student_id], true) }
                        item { RecordSectionTitle("Absent", absentRecords.size, false) }
                        items(absentRecords, key = { it.id }) { RecordRow(it, students[it.student_id], false) }
                    } else {
                        item { RecordSectionTitle(if (filter == AttendanceFilter.PRESENT) "Present" else "Absent", filtered.size, filter == AttendanceFilter.PRESENT) }
                        items(filtered, key = { it.id }) { record -> RecordRow(record, students[record.student_id], record.status.equals("present", true)) }
                    }
                }
            }
        }
    }
}

@Composable
private fun RecordCount(value: String, label: String, modifier: Modifier) {
    NeumorphicCard(modifier) { Column(Modifier.padding(14.dp)) { Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold); Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
}

@Composable
private fun RecordSectionTitle(title: String, count: Int, present: Boolean) {
    Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        Text(count.toString(), color = if (present) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.error)
    }
}

@Composable
private fun RecordRow(record: AttendanceRecord, student: Student?, present: Boolean) {
    NeumorphicCard(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(student?.full_name ?: "Unknown student", fontWeight = FontWeight.SemiBold)
                Text(student?.let { "${it.roll_number} • ${it.class_name.orEmpty()} ${it.division.orEmpty()}" } ?: record.student_id, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(if (present) "Present" else "Absent", color = if (present) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold)
        }
    }
}
