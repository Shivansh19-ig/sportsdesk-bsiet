package com.sportsdesk.data

import com.sportsdesk.data.model.*
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.query.Columns
import java.time.LocalDate

class SportsRepository {
    private val db = SupabaseClientProvider.client

    suspend fun getSports(): List<Sport> = db.from("sports").select {
        filter { eq("active", true) }
    }.decodeList()

    suspend fun addSport(name: String, emoji: String): Sport = db.from("sports")
        .insert(SportCreate(name.trim(), emoji.ifBlank { "🏅" }))
        .decodeSingle()

    suspend fun getStudents(): List<Student> = db.from("students")
        .select(Columns.ALL)
        .decodeList()

    suspend fun getStudentByAuthId(authUserId: String): Student? = runCatching {
        db.from("students").select {
            filter { eq("auth_user_id", authUserId) }
        }.decodeSingle<Student>()
    }.getOrNull()

    suspend fun createStudent(
        authUserId: String,
        rollNumber: String,
        fullName: String,
        className: String,
        division: String
    ): Student = db.from("students").insert(
        StudentCreate(
            roll_number = rollNumber.trim(),
            full_name = fullName.trim(),
            class_name = className.trim(),
            division = division.trim(),
            auth_user_id = authUserId
        )
    ).decodeSingle()

    suspend fun linkProfileToStudent(userId: String, studentId: String) {
        db.from("profiles").update({
            set("student_id", studentId)
        }) {
            filter { eq("id", userId) }
        }
    }

    suspend fun getSelectedSportIds(studentId: String): Set<String> = db
        .from("sport_memberships")
        .select {
            filter { eq("student_id", studentId) }
        }
        .decodeList<SportMembership>()
        .map { it.sport_id }
        .toSet()

    suspend fun getStudentsForSport(sportId: String): List<Student> {
        val studentIds = db.from("sport_memberships").select {
            filter { eq("sport_id", sportId) }
        }.decodeList<SportMembership>().map { it.student_id }

        if (studentIds.isEmpty()) return emptyList()
        return getStudentsByIds(studentIds).filter { it.active }.sortedByRollNumber()
    }

    suspend fun getStudentsByIds(studentIds: List<String>): List<Student> {
        if (studentIds.isEmpty()) return emptyList()
        return db.from("students").select(Columns.ALL) {
            filter { isIn("id", studentIds) }
        }.decodeList()
    }

    suspend fun getAttendanceSessions(sportId: String): List<AttendanceSession> =
        db.from("attendance_sessions").select {
            filter { eq("sport_id", sportId) }
        }.decodeList<AttendanceSession>()
            .sortedByDescending { it.attendance_date }


    suspend fun getAttendanceSession(sportId: String, date: String): AttendanceSession? = runCatching {
        db.from("attendance_sessions").select {
            filter {
                eq("sport_id", sportId)
                eq("attendance_date", date)
            }
        }.decodeSingle<AttendanceSession>()
    }.getOrNull()

    suspend fun getAttendanceRecords(sessionId: String): List<AttendanceRecord> =
        db.from("attendance_records").select {
            filter { eq("session_id", sessionId) }
        }.decodeList()

    suspend fun getAttendanceRecordsForSessions(sessionIds: List<String>): List<AttendanceRecord> {
        if (sessionIds.isEmpty()) return emptyList()
        return db.from("attendance_records").select {
            filter { isIn("session_id", sessionIds) }
        }.decodeList()
    }

    private fun List<Student>.sortedByRollNumber(): List<Student> = sortedWith(
        compareBy<Student> { it.roll_number.toIntOrNull() ?: Int.MAX_VALUE }
            .thenBy { it.roll_number }
            .thenBy { it.full_name.lowercase() }
    )

    suspend fun getOrCreateAttendanceSession(sportId: String, date: String): AttendanceSession {
        val existing = runCatching {
            db.from("attendance_sessions").select {
                filter {
                    eq("sport_id", sportId)
                    eq("attendance_date", date)
                }
            }.decodeSingle<AttendanceSession>()
        }.getOrNull()
        if (existing != null) return existing

        // Do not decode the INSERT response directly. Fetch the row after inserting;
        // this is safe even when PostgREST returns an empty/minimal response body.
        db.from("attendance_sessions").insert(
            AttendanceSessionCreate(sportId, date)
        )

        return db.from("attendance_sessions").select {
            filter {
                eq("sport_id", sportId)
                eq("attendance_date", date)
            }
        }.decodeSingle()
    }

    suspend fun saveAttendance(
        sportId: String,
        date: String = LocalDate.now().toString(),
        presentStudentIds: Set<String>,
        allStudentIds: List<String>
    ) {
        val payload = SaveAttendanceRpcParams(
            pSportId = sportId,
            pAttendanceDate = date,
            pPresentStudentIds = presentStudentIds.toList(),
            pAllStudentIds = allStudentIds
        )
        db.postgrest.rpc("teacher_save_attendance", payload)
    }

    suspend fun saveStudentSetup(
        rollNumber: String,
        fullName: String,
        className: String,
        division: String,
        selectedSportIds: Set<String>
    ): Student {
        require(rollNumber.matches(Regex("^[0-9]{1,10}$"))) { "Roll number must contain 1 to 10 digits." }
        require(fullName.trim().length in 2..80) { "Full name must be 2 to 80 characters." }
        require(className.trim().length in 1..40) { "Class must be 1 to 40 characters." }
        require(division.trim().length in 1..10) { "Division must be 1 to 10 characters." }

        return db.postgrest.rpc(
            "student_save_profile",
            StudentSetupRpcParams(
                pRollNumber = rollNumber.trim(),
                pFullName = fullName.trim(),
                pClassName = className.trim(),
                pDivision = division.trim(),
                pSportIds = selectedSportIds.toList()
            )
        ).decodeSingle()
    }

    suspend fun replaceStudentSports(studentId: String, selectedSportIds: Set<String>) {
        db.postgrest.rpc(
            "student_replace_sports",
            ReplaceSportsRpcParams(
                pStudentId = studentId,
                pSportIds = selectedSportIds.toList()
            )
        )
    }
}
