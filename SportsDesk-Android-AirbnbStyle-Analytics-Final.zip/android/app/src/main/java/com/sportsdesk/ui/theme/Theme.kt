package com.sportsdesk.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight

// SportsDesk keeps the generous, rounded, editorial visual language requested by the design reference,
// while using an original coral/blue sports palette rather than copying another product's branding.
private val Coral = Color(0xFFFF385C)
private val CoralDark = Color(0xFFE00B41)
private val Ink = Color(0xFF222222)
private val Body = Color(0xFF3F3F3F)
private val Muted = Color(0xFF6A6A6A)
private val Hairline = Color(0xFFE3E3E3)
private val Canvas = Color(0xFFFFFFFF)
private val SurfaceSoft = Color(0xFFF7F7F7)
private val Blue = Color(0xFF1677FF)

private val LightColors = lightColorScheme(
    primary = Coral,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFE2E7),
    onPrimaryContainer = Color(0xFF8C0B2A),
    secondary = Blue,
    onSecondary = Color.White,
    background = Canvas,
    onBackground = Ink,
    surface = Canvas,
    onSurface = Ink,
    surfaceVariant = SurfaceSoft,
    onSurfaceVariant = Muted,
    outline = Hairline,
    error = Color(0xFFC13515),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFFF6B83),
    onPrimary = Color(0xFF3A0612),
    primaryContainer = Color(0xFF651124),
    onPrimaryContainer = Color(0xFFFFD9E0),
    secondary = Color(0xFF7EB1FF),
    onSecondary = Color(0xFF062B63),
    background = Color(0xFF0F1115),
    onBackground = Color(0xFFF4F4F5),
    surface = Color(0xFF15181E),
    onSurface = Color(0xFFF4F4F5),
    surfaceVariant = Color(0xFF1D2128),
    onSurfaceVariant = Color(0xFFB7BDC7),
    outline = Color(0xFF343A44),
    error = Color(0xFFFF8A73),
)

@Composable
fun SportsDeskTheme(darkMode: Boolean, content: @Composable () -> Unit) {
    val base = Typography()
    MaterialTheme(
        colorScheme = if (darkMode) DarkColors else LightColors,
        typography = base.copy(
            displayLarge = base.displayLarge.copy(fontWeight = FontWeight.Bold),
            displayMedium = base.displayMedium.copy(fontWeight = FontWeight.SemiBold),
            headlineLarge = base.headlineLarge.copy(fontWeight = FontWeight.SemiBold),
            headlineMedium = base.headlineMedium.copy(fontWeight = FontWeight.SemiBold),
            titleLarge = base.titleLarge.copy(fontWeight = FontWeight.SemiBold),
            titleMedium = base.titleMedium.copy(fontWeight = FontWeight.SemiBold),
            bodyLarge = base.bodyLarge,
            bodyMedium = base.bodyMedium,
            labelLarge = base.labelLarge.copy(fontWeight = FontWeight.Medium),
        ),
        content = content
    )
}
