package com.sportsdesk.ui.dashboard

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.sportsdesk.data.SportsRepository
import com.sportsdesk.data.model.Sport
import com.sportsdesk.ui.components.BsietLogo
import com.sportsdesk.ui.components.NeumorphicCard
import kotlinx.coroutines.launch

@Composable
fun StudentSetupScreen(
    name: String,
    sports: List<Sport>,
    repository: SportsRepository,
    darkMode: Boolean,
    onToggleTheme: () -> Unit,
    onComplete: (Set<String>) -> Unit,
    onLogout: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var rollNumber by remember { mutableStateOf("") }
    var className by remember { mutableStateOf("") }
    var division by remember { mutableStateOf("") }
    var selection by remember { mutableStateOf<Set<String>>(emptySet()) }
    var error by remember { mutableStateOf("") }
    var saving by remember { mutableStateOf(false) }

    BackHandler { onLogout() }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        LazyColumn(
            Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    BsietLogo(Modifier.weight(1f))
                    IconButton(onClick = onToggleTheme) {
                        Icon(if (darkMode) Icons.Default.LightMode else Icons.Default.DarkMode, "Toggle theme")
                    }
                }
            }
            item {
                Text("Complete your profile", style = MaterialTheme.typography.headlineLarge)
                Text("This connects your account to the right college sports roster.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            item {
                NeumorphicCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Account name", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            item {
                ProfileField("Roll number", rollNumber) { rollNumber = it.filter(Char::isDigit).take(10) }
                Spacer(Modifier.height(12.dp))
                ProfileField("Class", className) { className = it.take(40) }
                Spacer(Modifier.height(12.dp))
                ProfileField("Division", division) { division = it.take(10) }
            }
            item {
                Text("Choose your sports", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                Text("You can join multiple sports and change them later.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (sports.isEmpty()) {
                item { Text("No sports are available yet. Ask the coach to add one.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
            } else {
                items(sports, key = { it.id }) { sport ->
                    val selected = sport.id in selection
                    NeumorphicCard(Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = selected, onCheckedChange = { selection = if (it) selection + sport.id else selection - sport.id })
                            Text(sport.emoji, style = MaterialTheme.typography.headlineSmall)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(sport.name, fontWeight = FontWeight.SemiBold)
                                Text("Active sport", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Box(
                                Modifier.size(10.dp).clip(RoundedCornerShape(999.dp)).background(if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline)
                            ) {}
                        }
                    }
                }
            }
            if (error.isNotBlank()) item { Text(error, color = MaterialTheme.colorScheme.error) }
            item {
                Button(
                    enabled = !saving && rollNumber.isNotBlank() && className.isNotBlank() && division.isNotBlank() && selection.isNotEmpty(),
                    onClick = {
                        scope.launch {
                            saving = true
                            error = ""
                            runCatching {
                                repository.saveStudentSetup(rollNumber, name, className, division, selection)
                            }.onSuccess { onComplete(selection) }
                                .onFailure { error = "We couldn't save your profile. Please check your details and try again." }
                            saving = false
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(999.dp)
                ) { Text(if (saving) "Saving profile…" else "Finish setup") }
            }
            item { OutlinedButton(onClick = onLogout, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(999.dp)) { Text("Log out") } }
        }
    }
}

@Composable
private fun ProfileField(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        shape = RoundedCornerShape(14.dp)
    )
}
