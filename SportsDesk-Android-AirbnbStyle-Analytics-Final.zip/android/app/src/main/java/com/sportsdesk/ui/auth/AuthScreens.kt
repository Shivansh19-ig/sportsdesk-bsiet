package com.sportsdesk.ui.auth

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.sportsdesk.data.AuthRepository
import com.sportsdesk.data.SupabaseClientProvider
import com.sportsdesk.ui.components.BsietLogo
import com.sportsdesk.ui.components.NeumorphicCard
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable


enum class LoginRole { TEACHER, STUDENT }

@Serializable
data class ProfileRole(
    val id: String,
    val role: String,
    val full_name: String? = null
)

@Composable
fun RolePickerScreen(
    darkMode: Boolean,
    onToggleTheme: () -> Unit,
    onTeacher: () -> Unit,
    onStudent: () -> Unit
) {
    AuthPage {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            BsietLogo(Modifier.weight(1f))
            IconButton(onClick = onToggleTheme) {
                Icon(if (darkMode) Icons.Default.LightMode else Icons.Default.DarkMode, "Toggle theme")
            }
        }
        Spacer(Modifier.height(48.dp))
        Text("College sports, organized.", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Take attendance in seconds, then understand every session with clean records and analytics.",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodyLarge
        )
        Spacer(Modifier.height(30.dp))
        LoginChoice("Teacher", "Manage sports, attendance and reports", Icons.Default.DarkMode, onTeacher)
        Spacer(Modifier.height(12.dp))
        LoginChoice("Student", "Choose your sports and view your attendance", Icons.Default.LightMode, onStudent)
        Spacer(Modifier.height(28.dp))
        Text("Organize • Track • Grow", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
private fun LoginChoice(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    NeumorphicCard(Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(28.dp))
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(4.dp))
            Button(
                onClick = onClick,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(999.dp)
            ) { Text("Continue") }
        }
    }
}

@Composable
fun PasswordLoginScreen(
    role: LoginRole,
    darkMode: Boolean,
    onToggleTheme: () -> Unit,
    onBack: () -> Unit,
    onSignedIn: (String) -> Unit,
    onStudentSignup: (() -> Unit)? = null
) {
    val repo = remember { AuthRepository() }
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }

    AuthPage {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
            BsietLogo(Modifier.weight(1f))
            IconButton(onClick = onToggleTheme) {
                Icon(if (darkMode) Icons.Default.LightMode else Icons.Default.DarkMode, "Toggle theme")
            }
        }
        Spacer(Modifier.height(28.dp))
        Text(if (role == LoginRole.TEACHER) "Teacher login" else "Student login", style = MaterialTheme.typography.headlineLarge)
        Text(
            if (role == LoginRole.TEACHER) "Authorized sports staff only" else "Sign in to your SportsDesk account",
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(22.dp))

        SportsTextField(email, { email = it }, "Email", KeyboardType.Email)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = {
                IconButton(onClick = { showPassword = !showPassword }) {
                    Icon(if (showPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility, if (showPassword) "Hide password" else "Show password")
                }
            }
        )
        Spacer(Modifier.height(16.dp))
        if (message.isNotBlank()) {
            Text(message, color = if (error) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(8.dp))
        }
        Button(
            enabled = email.isNotBlank() && password.isNotBlank() && !busy,
            onClick = {
                scope.launch {
                    busy = true; message = ""; error = false
                    try {
                        repo.signIn(email.trim(), password)
                        val session = SupabaseClientProvider.client.auth.currentSessionOrNull() ?: error("No active session returned")
                        val profile = SupabaseClientProvider.client.from("profiles").select {
                            filter { eq("id", session.user?.id?.toString().orEmpty()) }
                        }.decodeSingle<ProfileRole>()
                        val expected = if (role == LoginRole.TEACHER) "teacher" else "student"
                        if (profile.role.lowercase() != expected) {
                            repo.signOut()
                            error = true
                            message = if (role == LoginRole.TEACHER) "This account is not approved as a teacher." else "This account is not registered as a student."
                        } else {
                            onSignedIn(profile.full_name?.takeIf { it.isNotBlank() } ?: email.substringBefore("@"))
                        }
                    } catch (e: Exception) {
                        error = true
                        message = readableAuthError(e)
                    } finally { busy = false }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(999.dp)
        ) { Text(if (busy) "Signing in…" else "Sign in") }

        if (role == LoginRole.STUDENT && onStudentSignup != null) {
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onStudentSignup, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(999.dp)) {
                Text("Create student account")
            }
        }
        if (role == LoginRole.TEACHER) {
            Spacer(Modifier.height(18.dp))
            NeumorphicCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Teacher accounts are controlled", fontWeight = FontWeight.SemiBold)
                    Text("A sports administrator creates or approves teacher access. Students cannot promote themselves to teacher.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
fun StudentSignupScreen(
    darkMode: Boolean,
    onToggleTheme: () -> Unit,
    onBack: () -> Unit,
    onCreated: () -> Unit
) {
    val repo = remember { AuthRepository() }
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }

    AuthPage {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
            BsietLogo(Modifier.weight(1f))
            IconButton(onClick = onToggleTheme) { Icon(if (darkMode) Icons.Default.LightMode else Icons.Default.DarkMode, "Toggle theme") }
        }
        Spacer(Modifier.height(28.dp))
        Text("Create student account", style = MaterialTheme.typography.headlineLarge)
        Text("Your role is created as student automatically.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(20.dp))
        SportsTextField(name, { name = it }, "Full name", KeyboardType.Text)
        Spacer(Modifier.height(12.dp))
        SportsTextField(email, { email = it }, "Email", KeyboardType.Email)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            supportingText = { Text("Use at least 10 characters") },
            visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = {
                IconButton(onClick = { showPassword = !showPassword }) {
                    Icon(if (showPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility, if (showPassword) "Hide password" else "Show password")
                }
            }
        )
        Spacer(Modifier.height(12.dp))
        if (message.isNotBlank()) Text(message, color = if (error) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(8.dp))
        Button(
            enabled = !busy && name.trim().length >= 2 && email.contains("@") && password.length >= 10,
            onClick = {
                scope.launch {
                    busy = true; message = ""; error = false
                    try {
                        repo.signUpStudent(email.trim(), password, name.trim())
                        message = "Account created. Confirm the email if Supabase asks, then sign in."
                        onCreated()
                    } catch (e: Exception) {
                        error = true
                        message = readableAuthError(e)
                    } finally { busy = false }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(999.dp)
        ) { Text(if (busy) "Creating…" else "Create account") }
    }
}

@Composable
private fun SportsTextField(value: String, onValueChange: (String) -> Unit, label: String, keyboardType: KeyboardType) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType)
    )
}

@Composable
private fun AuthPage(content: @Composable ColumnScope.() -> Unit) {
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier.fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .verticalScroll(rememberScrollState())
                .imePadding()
                .padding(horizontal = 20.dp, vertical = 18.dp),
            content = content
        )
    }
}

private fun readableAuthError(error: Throwable): String {
    val raw = error.message.orEmpty()
    return when {
        raw.contains("Invalid login credentials", true) -> "Email or password is incorrect."
        raw.contains("Email not confirmed", true) -> "Please confirm your email before signing in."
        raw.contains("rate limit", true) -> "Email service rate limit reached. Try again later."
        raw.contains("already registered", true) -> "An account with this email already exists."
        else -> "We couldn't complete that request. Please check your details and try again."
    }
}
