# Supabase Edge Functions

Keep privileged/server-only operations here.

Do NOT put the Supabase service-role key inside the Android app.

Suggested future functions:
- `generate-report` — create server-side report data
- `bulk-import-students` — validate/import CSV files
- `admin-audit` — controlled administrative operations
