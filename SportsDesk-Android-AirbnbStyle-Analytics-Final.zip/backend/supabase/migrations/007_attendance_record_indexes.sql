create index if not exists attendance_sessions_sport_date_idx
  on public.attendance_sessions (sport_id, attendance_date desc);

create index if not exists attendance_records_session_status_idx
  on public.attendance_records (session_id, status);

create index if not exists attendance_records_student_idx
  on public.attendance_records (student_id);

create index if not exists sport_memberships_student_sport_idx
  on public.sport_memberships (student_id, sport_id);

create index if not exists profiles_student_id_idx on public.profiles (student_id);
