-- SportsDesk security hardening.
-- Removes the original authenticated-wide CRUD policies and replaces them
-- with teacher/student RLS boundaries that do not recurse through profiles.

create schema if not exists private;

create or replace function private.is_teacher()
returns boolean
language sql
security definer
stable
set search_path = ''
as $$
  select exists (
    select 1
    from public.profiles p
    where p.id = (select auth.uid())
      and p.role = 'teacher'
  );
$$;

create or replace function private.current_student_id()
returns uuid
language sql
security definer
stable
set search_path = ''
as $$
  select s.id
  from public.students s
  where s.auth_user_id = (select auth.uid())
  limit 1;
$$;

create or replace function private.student_belongs_to_current_user(p_student_id uuid)
returns boolean
language sql
security definer
stable
set search_path = ''
as $$
  select exists (
    select 1
    from public.students s
    where s.id = p_student_id
      and s.auth_user_id = (select auth.uid())
  );
$$;

revoke all on function private.is_teacher() from public, anon, authenticated;
revoke all on function private.current_student_id() from public, anon, authenticated;
revoke all on function private.student_belongs_to_current_user(uuid) from public, anon, authenticated;
grant execute on function private.is_teacher() to authenticated;
grant execute on function private.current_student_id() to authenticated;
grant execute on function private.student_belongs_to_current_user(uuid) to authenticated;

-- Remove the broad policies from the original migration and earlier patches.
drop policy if exists "authenticated sports access" on public.sports;
drop policy if exists "Authenticated users can view sports" on public.sports;
drop policy if exists "Teachers can manage sports" on public.sports;

create policy "Authenticated users can view sports"
on public.sports
for select to authenticated
using (true);

create policy "Teachers can manage sports"
on public.sports
for all to authenticated
using ((select private.is_teacher()))
with check ((select private.is_teacher()));

-- Students
drop policy if exists "authenticated students access" on public.students;
drop policy if exists "Students can view own student record" on public.students;
drop policy if exists "Students can create own student record" on public.students;
drop policy if exists "Students can update own student record" on public.students;
drop policy if exists "Teachers can view all students" on public.students;
drop policy if exists "Teachers can insert students" on public.students;
drop policy if exists "Teachers can update all students" on public.students;
drop policy if exists "Teachers can delete all students" on public.students;

create policy "Teachers can view all students"
on public.students
for select to authenticated
using ((select private.is_teacher()));

create policy "Students can view own student record"
on public.students
for select to authenticated
using (auth_user_id = (select auth.uid()));

create policy "Teachers can insert students"
on public.students
for insert to authenticated
with check ((select private.is_teacher()));

create policy "Students can create own student record"
on public.students
for insert to authenticated
with check (auth_user_id = (select auth.uid()));

create policy "Teachers can update all students"
on public.students
for update to authenticated
using ((select private.is_teacher()))
with check ((select private.is_teacher()));

create policy "Students can update own student record"
on public.students
for update to authenticated
using (auth_user_id = (select auth.uid()))
with check (auth_user_id = (select auth.uid()));

create policy "Teachers can delete all students"
on public.students
for delete to authenticated
using ((select private.is_teacher()));

-- Profiles: a user can read/update their own profile, but role changes are
-- protected by a trigger so normal clients cannot self-promote to teacher.
drop policy if exists "users can read own profile" on public.profiles;
drop policy if exists "Users can read their own profile" on public.profiles;
drop policy if exists "users can update own profile" on public.profiles;
drop policy if exists "Users can update their own profile" on public.profiles;
drop policy if exists "Users can update their own profile" on public.profiles;
drop policy if exists "Students can update their own profile" on public.profiles;
drop policy if exists "Users can update their own profile" on public.profiles;

create policy "Users can read their own profile"
on public.profiles
for select to authenticated
using ((select auth.uid()) = id);

create policy "Users can update their own profile"
on public.profiles
for update to authenticated
using ((select auth.uid()) = id)
with check (
  (select auth.uid()) = id
  and (
    student_id is null
    or (select private.student_belongs_to_current_user(student_id))
  )
);

create or replace function private.protect_profile_role()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if (select auth.uid()) is not null
     and new.role is distinct from old.role then
    raise exception 'Profile role can only be changed by an administrator';
  end if;
  return new;
end;
$$;

revoke all on function private.protect_profile_role() from public, anon, authenticated;

drop trigger if exists protect_profile_role on public.profiles;
create trigger protect_profile_role
before update on public.profiles
for each row execute procedure private.protect_profile_role();

-- Sport memberships
drop policy if exists "authenticated memberships access" on public.sport_memberships;
drop policy if exists "Students can join own sports" on public.sport_memberships;
drop policy if exists "Students can leave own sports" on public.sport_memberships;
drop policy if exists "Students can view own sport memberships" on public.sport_memberships;
drop policy if exists "Teachers can manage sport memberships" on public.sport_memberships;

create policy "Students can view own sport memberships"
on public.sport_memberships
for select to authenticated
using ((select private.student_belongs_to_current_user(student_id)));

create policy "Teachers can manage sport memberships"
on public.sport_memberships
for all to authenticated
using ((select private.is_teacher()))
with check ((select private.is_teacher()));

create policy "Students can join own sports"
on public.sport_memberships
for insert to authenticated
with check (
  (select private.student_belongs_to_current_user(student_id))
  and exists (
    select 1
    from public.sports s
    where s.id = sport_id
      and s.active = true
  )
);

create policy "Students can leave own sports"
on public.sport_memberships
for delete to authenticated
using ((select private.student_belongs_to_current_user(student_id)));

-- Attendance sessions
drop policy if exists "authenticated sessions access" on public.attendance_sessions;
drop policy if exists "Students can view own attendance sessions" on public.attendance_sessions;
drop policy if exists "Teachers can manage attendance sessions" on public.attendance_sessions;

create policy "Teachers can manage attendance sessions"
on public.attendance_sessions
for all to authenticated
using ((select private.is_teacher()))
with check ((select private.is_teacher()));

create policy "Students can view own attendance sessions"
on public.attendance_sessions
for select to authenticated
using (
  exists (
    select 1
    from public.attendance_records ar
    where ar.session_id = attendance_sessions.id
      and ar.student_id = (select private.current_student_id())
  )
);

-- Attendance records
drop policy if exists "authenticated records access" on public.attendance_records;
drop policy if exists "Students can view own attendance" on public.attendance_records;
drop policy if exists "Teachers can manage attendance records" on public.attendance_records;

create policy "Teachers can manage attendance records"
on public.attendance_records
for all to authenticated
using ((select private.is_teacher()))
with check ((select private.is_teacher()));

create policy "Students can view own attendance"
on public.attendance_records
for select to authenticated
using (student_id = (select private.current_student_id()));

-- API grants: no anonymous client access to application tables.
revoke all on public.sports, public.students, public.sport_memberships,
  public.attendance_sessions, public.attendance_records, public.profiles
  from anon, public;

grant select, insert, update, delete on public.sports to authenticated;
grant select, insert, update, delete on public.students to authenticated;
grant select, insert, delete on public.sport_memberships to authenticated;
grant select, insert, update, delete on public.attendance_sessions to authenticated;
grant select, insert, update, delete on public.attendance_records to authenticated;
grant select, update on public.profiles to authenticated;

-- The RLS event-trigger helper is platform-level infrastructure and must not
-- be callable through the public Data API.
revoke all on function public.rls_auto_enable() from public, anon, authenticated;

-- Student-controlled security fields are protected at the row level.
create or replace function private.protect_student_security_fields()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if (select auth.uid()) is not null
     and old.auth_user_id = (select auth.uid()) then
    if new.auth_user_id is distinct from old.auth_user_id then
      raise exception 'Student account link cannot be changed by the student';
    end if;
    if new.active is distinct from old.active then
      raise exception 'Student active status can only be changed by a teacher';
    end if;
    if new.roll_number is distinct from old.roll_number then
      raise exception 'Roll number can only be changed by a teacher';
    end if;
  end if;
  return new;
end;
$$;

revoke all on function private.protect_student_security_fields() from public, anon, authenticated;
drop trigger if exists protect_student_security_fields on public.students;
create trigger protect_student_security_fields
before update on public.students
for each row execute procedure private.protect_student_security_fields();

-- Optional teacher access requests: do not accept anonymous spam through the Data API.
create table if not exists public.teacher_requests (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  email text not null,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  requested_at timestamptz not null default now(),
  reviewed_at timestamptz
);
alter table public.teacher_requests enable row level security;
drop policy if exists "Anyone can submit teacher access request" on public.teacher_requests;
drop policy if exists "Authenticated users can submit teacher access request" on public.teacher_requests;
create policy "Authenticated users can submit teacher access request"
on public.teacher_requests
for insert to authenticated
with check (status = 'pending');
revoke all on public.teacher_requests from anon, public;
grant insert on public.teacher_requests to authenticated;
