-- OPTIONAL DEVELOPMENT CLEANUP ONLY.
-- Use this only if the six starter sports were test data and are not actual college sports.
-- This does NOT delete students, memberships, or attendance.
-- Remove or archive the rows manually if any of these are real sports at your college.

-- delete from public.sports
-- where lower(name) in ('football', 'cricket', 'basketball', 'athletics', 'volleyball', 'kabaddi');
