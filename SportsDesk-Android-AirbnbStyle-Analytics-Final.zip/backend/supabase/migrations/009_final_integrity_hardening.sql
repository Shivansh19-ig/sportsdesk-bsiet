-- Final integrity hardening for SportsDesk.
-- Atomic student setup, sport selection, and teacher attendance writes.

create schema if not exists private;

-- Server-side validation constraints.
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'students_roll_number_format') THEN
    ALTER TABLE public.students
      ADD CONSTRAINT students_roll_number_format
      CHECK (roll_number ~ '^[0-9]{1,10}$');
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'students_full_name_length') THEN
    ALTER TABLE public.students
      ADD CONSTRAINT students_full_name_length
      CHECK (length(btrim(full_name)) BETWEEN 2 AND 80);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'students_class_name_length') THEN
    ALTER TABLE public.students
      ADD CONSTRAINT students_class_name_length
      CHECK (class_name IS NULL OR length(btrim(class_name)) BETWEEN 1 AND 40);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'students_division_length') THEN
    ALTER TABLE public.students
      ADD CONSTRAINT students_division_length
      CHECK (division IS NULL OR length(btrim(division)) BETWEEN 1 AND 10);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'sports_name_length') THEN
    ALTER TABLE public.sports
      ADD CONSTRAINT sports_name_length
      CHECK (length(btrim(name)) BETWEEN 2 AND 40);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'sports_emoji_length') THEN
    ALTER TABLE public.sports
      ADD CONSTRAINT sports_emoji_length
      CHECK (length(emoji) BETWEEN 1 AND 8);
  END IF;
END $$;

CREATE UNIQUE INDEX IF NOT EXISTS sports_name_unique_ci
  ON public.sports (lower(name));

CREATE INDEX IF NOT EXISTS attendance_sessions_sport_date_idx
  ON public.attendance_sessions (sport_id, attendance_date DESC);
CREATE INDEX IF NOT EXISTS attendance_records_session_status_idx
  ON public.attendance_records (session_id, status);
CREATE INDEX IF NOT EXISTS attendance_records_student_idx
  ON public.attendance_records (student_id);
CREATE INDEX IF NOT EXISTS sport_memberships_student_sport_idx
  ON public.sport_memberships (student_id, sport_id);
CREATE INDEX IF NOT EXISTS profiles_student_id_idx
  ON public.profiles (student_id);

-- Every attendance row must belong to a student who is a member of that session's sport.
CREATE OR REPLACE FUNCTION private.validate_attendance_membership()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
STABLE
SET search_path = ''
AS $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM public.attendance_sessions s
    JOIN public.sport_memberships sm
      ON sm.sport_id = s.sport_id
     AND sm.student_id = NEW.student_id
    JOIN public.students st
      ON st.id = NEW.student_id
     AND st.active = true
    WHERE s.id = NEW.session_id
  ) THEN
    RAISE EXCEPTION 'Attendance student is not an active member of the session sport';
  END IF;
  RETURN NEW;
END;
$$;

REVOKE ALL ON FUNCTION private.validate_attendance_membership() FROM public, anon, authenticated;
DROP TRIGGER IF EXISTS validate_attendance_membership ON public.attendance_records;
CREATE TRIGGER validate_attendance_membership
BEFORE INSERT OR UPDATE ON public.attendance_records
FOR EACH ROW EXECUTE PROCEDURE private.validate_attendance_membership();

-- Atomic attendance write. The function runs in one database transaction.
CREATE OR REPLACE FUNCTION public.teacher_save_attendance(
  p_sport_id uuid,
  p_attendance_date date,
  p_present_student_ids uuid[],
  p_all_student_ids uuid[]
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_session_id uuid;
  v_invalid_count integer;
BEGIN
  IF NOT (SELECT private.is_teacher()) THEN
    RAISE EXCEPTION 'Teacher role required';
  END IF;

  IF p_all_student_ids IS NULL OR cardinality(p_all_student_ids) = 0 THEN
    RAISE EXCEPTION 'Attendance list cannot be empty';
  END IF;

  SELECT count(*) INTO v_invalid_count
  FROM unnest(p_all_student_ids) AS requested(student_id)
  WHERE NOT EXISTS (
    SELECT 1
    FROM public.students st
    JOIN public.sport_memberships sm ON sm.student_id = st.id
    WHERE st.id = requested.student_id
      AND st.active = true
      AND sm.sport_id = p_sport_id
  );

  IF v_invalid_count > 0 THEN
    RAISE EXCEPTION 'Attendance list contains students outside the selected sport';
  END IF;

  IF p_present_student_ids IS NULL THEN
    p_present_student_ids := ARRAY[]::uuid[];
  END IF;

  IF EXISTS (
    SELECT 1
    FROM unnest(p_present_student_ids) AS present(student_id)
    WHERE NOT (present.student_id = ANY(p_all_student_ids))
  ) THEN
    RAISE EXCEPTION 'Present list contains a student outside the attendance list';
  END IF;

  INSERT INTO public.attendance_sessions (sport_id, attendance_date)
  VALUES (p_sport_id, p_attendance_date)
  ON CONFLICT (sport_id, attendance_date)
  DO UPDATE SET attendance_date = EXCLUDED.attendance_date
  RETURNING id INTO v_session_id;

  DELETE FROM public.attendance_records
  WHERE session_id = v_session_id
    AND NOT (student_id = ANY(p_all_student_ids));

  INSERT INTO public.attendance_records (session_id, student_id, status, marked_at)
  SELECT
    v_session_id,
    requested.student_id,
    CASE WHEN requested.student_id = ANY(p_present_student_ids)
      THEN 'present' ELSE 'absent' END,
    now()
  FROM unnest(p_all_student_ids) AS requested(student_id)
  ON CONFLICT (session_id, student_id)
  DO UPDATE SET
    status = EXCLUDED.status,
    marked_at = now();

  RETURN v_session_id;
END;
$$;

REVOKE ALL ON FUNCTION public.teacher_save_attendance(uuid, date, uuid[], uuid[]) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.teacher_save_attendance(uuid, date, uuid[], uuid[]) TO authenticated;

-- Atomic replacement of a student's selected sports.
CREATE OR REPLACE FUNCTION public.student_replace_sports(
  p_student_id uuid,
  p_sport_ids uuid[]
)
RETURNS void
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_is_teacher boolean := (SELECT private.is_teacher());
  v_is_owner boolean := (SELECT private.student_belongs_to_current_user(p_student_id));
  v_invalid_count integer;
BEGIN
  IF NOT v_is_teacher AND NOT v_is_owner THEN
    RAISE EXCEPTION 'Not authorized to edit this student sports selection';
  END IF;

  IF p_sport_ids IS NULL THEN
    p_sport_ids := ARRAY[]::uuid[];
  END IF;

  SELECT count(*) INTO v_invalid_count
  FROM unnest(p_sport_ids) requested(sport_id)
  WHERE NOT EXISTS (
    SELECT 1 FROM public.sports s
    WHERE s.id = requested.sport_id AND s.active = true
  );

  IF v_invalid_count > 0 THEN
    RAISE EXCEPTION 'One or more selected sports are unavailable';
  END IF;

  DELETE FROM public.sport_memberships WHERE student_id = p_student_id;

  INSERT INTO public.sport_memberships (sport_id, student_id)
  SELECT DISTINCT requested.sport_id, p_student_id
  FROM unnest(p_sport_ids) requested(sport_id);
END;
$$;

REVOKE ALL ON FUNCTION public.student_replace_sports(uuid, uuid[]) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.student_replace_sports(uuid, uuid[]) TO authenticated;

-- Atomic student profile setup. Existing students keep their original roll number.
CREATE OR REPLACE FUNCTION public.student_save_profile(
  p_roll_number text,
  p_full_name text,
  p_class_name text,
  p_division text,
  p_sport_ids uuid[]
)
RETURNS public.students
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public, pg_temp
AS $$
DECLARE
  v_uid uuid := (SELECT auth.uid());
  v_student public.students;
  v_existing_id uuid;
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'Authentication required';
  END IF;

  IF p_roll_number !~ '^[0-9]{1,10}$' THEN
    RAISE EXCEPTION 'Roll number must contain 1 to 10 digits';
  END IF;
  IF length(btrim(p_full_name)) NOT BETWEEN 2 AND 80 THEN
    RAISE EXCEPTION 'Full name must be 2 to 80 characters';
  END IF;
  IF length(btrim(p_class_name)) NOT BETWEEN 1 AND 40 THEN
    RAISE EXCEPTION 'Class must be 1 to 40 characters';
  END IF;
  IF length(btrim(p_division)) NOT BETWEEN 1 AND 10 THEN
    RAISE EXCEPTION 'Division must be 1 to 10 characters';
  END IF;

  SELECT id INTO v_existing_id
  FROM public.students
  WHERE auth_user_id = v_uid
  LIMIT 1;

  IF v_existing_id IS NULL THEN
    INSERT INTO public.students (roll_number, full_name, class_name, division, auth_user_id)
    VALUES (btrim(p_roll_number), btrim(p_full_name), btrim(p_class_name), btrim(p_division), v_uid)
    RETURNING * INTO v_student;

    UPDATE public.profiles
    SET student_id = v_student.id,
        full_name = v_student.full_name,
        updated_at = now()
    WHERE id = v_uid;
  ELSE
    UPDATE public.students
    SET full_name = btrim(p_full_name),
        class_name = btrim(p_class_name),
        division = btrim(p_division)
    WHERE id = v_existing_id
    RETURNING * INTO v_student;

    UPDATE public.profiles
    SET student_id = v_student.id,
        full_name = v_student.full_name,
        updated_at = now()
    WHERE id = v_uid;
  END IF;

  PERFORM public.student_replace_sports(v_student.id, p_sport_ids);
  RETURN v_student;
END;
$$;

REVOKE ALL ON FUNCTION public.student_save_profile(text, text, text, text, uuid[]) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.student_save_profile(text, text, text, text, uuid[]) TO authenticated;

-- Teacher requests belong in the reproducible schema even if a deployment skipped
-- the earlier optional migration.
CREATE TABLE IF NOT EXISTS public.teacher_requests (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  email text not null,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  requested_at timestamptz not null default now(),
  reviewed_at timestamptz
);
ALTER TABLE public.teacher_requests ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.teacher_requests FROM anon, public;
GRANT INSERT ON public.teacher_requests TO authenticated;
DROP POLICY IF EXISTS "Authenticated users can submit teacher access request" ON public.teacher_requests;
CREATE POLICY "Authenticated users can submit teacher access request"
ON public.teacher_requests
FOR INSERT TO authenticated
WITH CHECK (status = 'pending');
