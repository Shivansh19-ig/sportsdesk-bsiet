-- Fix teacher visibility and student membership reads without creating RLS recursion.

create or replace function private.is_teacher()
returns boolean
language sql
security definer
stable
set search_path = ''
AS $$
  select exists (
    select 1
    from public.profiles p
    where p.id = (select auth.uid())
      and p.role = 'teacher'
  );
$$;

revoke all on function private.is_teacher() from public;
grant execute on function private.is_teacher() to authenticated;

create policy "Teachers can view all students"
on public.students
for select
to authenticated
using ((select private.is_teacher()));

create policy "Teachers can insert students"
on public.students
for insert
to authenticated
with check ((select private.is_teacher()));

create policy "Teachers can update all students"
on public.students
for update
to authenticated
using ((select private.is_teacher()))
with check ((select private.is_teacher()));

create policy "Teachers can delete all students"
on public.students
for delete
to authenticated
using ((select private.is_teacher()));

create policy "Teachers can manage sport memberships"
on public.sport_memberships
for all
to authenticated
using ((select private.is_teacher()))
with check ((select private.is_teacher()));

create policy "Students can view own sport memberships"
on public.sport_memberships
for select
to authenticated
using (
  student_id in (
    select p.student_id
    from public.profiles p
    where p.id = (select auth.uid())
  )
);
