create extension if not exists pgcrypto;

create table if not exists public.sports (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  emoji text default '🏅',
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.students (
  id uuid primary key default gen_random_uuid(),
  roll_number text not null unique,
  full_name text not null,
  class_name text,
  division text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.sport_memberships (
  id uuid primary key default gen_random_uuid(),
  sport_id uuid not null references public.sports(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (sport_id, student_id)
);

create table if not exists public.attendance_sessions (
  id uuid primary key default gen_random_uuid(),
  sport_id uuid not null references public.sports(id) on delete cascade,
  attendance_date date not null,
  created_at timestamptz not null default now(),
  unique (sport_id, attendance_date)
);

create table if not exists public.attendance_records (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null references public.attendance_sessions(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  status text not null check (status in ('present','absent')),
  marked_at timestamptz not null default now(),
  unique (session_id, student_id)
);

alter table public.sports enable row level security;
alter table public.students enable row level security;
alter table public.sport_memberships enable row level security;
alter table public.attendance_sessions enable row level security;
alter table public.attendance_records enable row level security;

-- RLS is enabled here, but least-privilege policies are created by the
-- role-aware/auth migrations that follow. The database is secure-by-default
-- if only this migration has been applied.

insert into public.sports (name, emoji)
select x.name, x.emoji
from (values
  ('Football','⚽'),
  ('Cricket','🏏'),
  ('Basketball','🏀'),
  ('Athletics','🏃'),
  ('Volleyball','🏐'),
  ('Kabaddi','🤼'),
  ('Badminton','🏸'),
  ('Table Tennis','🏓'),
  ('Chess','♟️'),
  ('Kho-Kho','🏃‍♂️')
) as x(name, emoji)
where not exists (
  select 1 from public.sports s where s.name = x.name
);
