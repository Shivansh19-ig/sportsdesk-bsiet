-- Optional teacher access-request table.
-- It does NOT grant teacher access; approval remains administrative.

create table if not exists public.teacher_requests (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  email text not null,
  status text not null default 'pending'
    check (status in ('pending','approved','rejected')),
  requested_at timestamptz not null default now(),
  reviewed_at timestamptz
);

alter table public.teacher_requests enable row level security;

drop policy if exists "Anyone can submit teacher access request"
on public.teacher_requests;

create policy "Authenticated users can submit teacher access request"
on public.teacher_requests
for insert
to authenticated
with check (status = 'pending');
