-- SportsDesk final policy/integrity cleanup.
-- Run after 009_final_integrity_hardening.sql.
-- This migration mirrors the hardened production policy shape used by SportsDesk.

create schema if not exists private;

-- Teacher/ownership helper functions are kept out of exposed schemas.
create or replace function private.is_teacher()
returns boolean
language sql
security definer
stable
set search_path = ''
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = (select auth.uid()) and p.role = 'teacher'
  );
$$;

create or replace function private.current_student_id()
returns uuid
language sql
security definer
stable
set search_path = ''
as $$
  select s.id from public.students s
  where s.auth_user_id = (select auth.uid())
  limit 1;
$$;

create or replace function private.student_belongs_to_current_user(p_student_id uuid)
returns boolean
language sql
security definer
stable
set search_path = ''
as $$
  select exists (
    select 1 from public.students s
    where s.id = p_student_id and s.auth_user_id = (select auth.uid())
  );
$$;

revoke all on function private.is_teacher() from public, anon, authenticated;
revoke all on function private.current_student_id() from public, anon, authenticated;
revoke all on function private.student_belongs_to_current_user(uuid) from public, anon, authenticated;
grant execute on function private.is_teacher() to authenticated;
grant execute on function private.current_student_id() to authenticated;
grant execute on function private.student_belongs_to_current_user(uuid) to authenticated;

-- Role changes are administrator-only. Students cannot promote themselves.
create or replace function private.protect_profile_role()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if (select auth.uid()) is not null and new.role is distinct from old.role then
    raise exception 'Profile role can only be changed by an administrator';
  end if;
  return new;
end;
$$;
revoke all on function private.protect_profile_role() from public, anon, authenticated;
drop trigger if exists protect_profile_role on public.profiles;
create trigger protect_profile_role
before update on public.profiles
for each row execute procedure private.protect_profile_role();

-- Student-controlled security fields are protected.
create or replace function private.protect_student_security_fields()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if (select auth.uid()) is not null and old.auth_user_id = (select auth.uid()) then
    if new.auth_user_id is distinct from old.auth_user_id then
      raise exception 'Student account link cannot be changed by the student';
    end if;
    if new.active is distinct from old.active then
      raise exception 'Student active status can only be changed by a teacher';
    end if;
    if new.roll_number is distinct from old.roll_number then
      raise exception 'Roll number can only be changed by a teacher';
    end if;
  end if;
  return new;
end;
$$;
revoke all on function private.protect_student_security_fields() from public, anon, authenticated;
drop trigger if exists protect_student_security_fields on public.students;
create trigger protect_student_security_fields
before update on public.students
for each row execute procedure private.protect_student_security_fields();

-- Exactly one readable policy per role/action, keeping authorization simple to audit.
drop policy if exists "Teachers can manage sports" on public.sports;
drop policy if exists "Authenticated users can view sports" on public.sports;
create policy "Users can view sports" on public.sports
for select to authenticated using (true);
create policy "Teachers can insert sports" on public.sports
for insert to authenticated with check ((select private.is_teacher()));
create policy "Teachers can update sports" on public.sports
for update to authenticated using ((select private.is_teacher())) with check ((select private.is_teacher()));
create policy "Teachers can delete sports" on public.sports
for delete to authenticated using ((select private.is_teacher()));

drop policy if exists "Teachers can view all students" on public.students;
drop policy if exists "Students can view own student record" on public.students;
drop policy if exists "Teachers can insert students" on public.students;
drop policy if exists "Students can create own student record" on public.students;
drop policy if exists "Teachers can update all students" on public.students;
drop policy if exists "Students can update own student record" on public.students;
drop policy if exists "Teachers can delete all students" on public.students;
create policy "Users can view permitted students" on public.students
for select to authenticated using ((select private.is_teacher()) or auth_user_id = (select auth.uid()));
create policy "Users can create permitted students" on public.students
for insert to authenticated with check ((select private.is_teacher()) or auth_user_id = (select auth.uid()));
create policy "Users can update permitted students" on public.students
for update to authenticated
using ((select private.is_teacher()) or auth_user_id = (select auth.uid()))
with check ((select private.is_teacher()) or auth_user_id = (select auth.uid()));
create policy "Teachers can delete students" on public.students
for delete to authenticated using ((select private.is_teacher()));

drop policy if exists "Teachers can manage sport memberships" on public.sport_memberships;
drop policy if exists "Students can view own sport memberships" on public.sport_memberships;
drop policy if exists "Students can join own sports" on public.sport_memberships;
drop policy if exists "Students can leave own sports" on public.sport_memberships;
create policy "Users can view permitted sport memberships" on public.sport_memberships
for select to authenticated using ((select private.is_teacher()) or (select private.student_belongs_to_current_user(student_id)));
create policy "Users can create permitted sport memberships" on public.sport_memberships
for insert to authenticated
with check (
  ((select private.is_teacher()) or (select private.student_belongs_to_current_user(student_id)))
  and exists (select 1 from public.sports s where s.id = sport_id and s.active = true)
);
create policy "Users can delete permitted sport memberships" on public.sport_memberships
for delete to authenticated using ((select private.is_teacher()) or (select private.student_belongs_to_current_user(student_id)));

drop policy if exists "Teachers can manage attendance sessions" on public.attendance_sessions;
drop policy if exists "Students can view own attendance sessions" on public.attendance_sessions;
create policy "Users can view permitted attendance sessions" on public.attendance_sessions
for select to authenticated using (
  (select private.is_teacher())
  or exists (
    select 1 from public.attendance_records ar
    where ar.session_id = attendance_sessions.id
      and ar.student_id = (select private.current_student_id())
  )
);
create policy "Teachers can insert attendance sessions" on public.attendance_sessions
for insert to authenticated with check ((select private.is_teacher()));
create policy "Teachers can update attendance sessions" on public.attendance_sessions
for update to authenticated using ((select private.is_teacher())) with check ((select private.is_teacher()));
create policy "Teachers can delete attendance sessions" on public.attendance_sessions
for delete to authenticated using ((select private.is_teacher()));

drop policy if exists "Teachers can manage attendance records" on public.attendance_records;
drop policy if exists "Students can view own attendance" on public.attendance_records;
create policy "Users can view permitted attendance" on public.attendance_records
for select to authenticated using ((select private.is_teacher()) or student_id = (select private.current_student_id()));
create policy "Teachers can insert attendance records" on public.attendance_records
for insert to authenticated with check ((select private.is_teacher()));
create policy "Teachers can update attendance records" on public.attendance_records
for update to authenticated using ((select private.is_teacher())) with check ((select private.is_teacher()));
create policy "Teachers can delete attendance records" on public.attendance_records
for delete to authenticated using ((select private.is_teacher()));

-- Public API is not anonymous-accessible for these application tables.
revoke all on public.sports, public.students, public.sport_memberships,
  public.attendance_sessions, public.attendance_records, public.profiles
  from anon, public;

grant select, insert, update, delete on public.sports to authenticated;
grant select, insert, update, delete on public.students to authenticated;
grant select, insert, delete on public.sport_memberships to authenticated;
grant select, insert, update, delete on public.attendance_sessions to authenticated;
grant select, insert, update, delete on public.attendance_records to authenticated;
grant select, update on public.profiles to authenticated;

-- Hardening for the old event-trigger helper: it stays database-internal.
revoke all on function public.rls_auto_enable() from public, anon, authenticated;

-- Keep the attendance write function current: reject future dates and inactive sports.
create or replace function public.teacher_save_attendance(
  p_sport_id uuid,
  p_attendance_date date,
  p_present_student_ids uuid[],
  p_all_student_ids uuid[]
)
returns uuid
language plpgsql
security invoker
set search_path = public, pg_temp
as $$
declare
  v_session_id uuid;
  v_invalid_count integer;
begin
  if not (select private.is_teacher()) then raise exception 'Teacher role required'; end if;
  if p_attendance_date > current_date then raise exception 'Attendance date cannot be in the future'; end if;
  if not exists (select 1 from public.sports where id = p_sport_id and active = true) then raise exception 'Sport is inactive or unavailable'; end if;
  if p_all_student_ids is null or cardinality(p_all_student_ids) = 0 then raise exception 'Attendance list cannot be empty'; end if;

  select count(*) into v_invalid_count
  from unnest(p_all_student_ids) requested(student_id)
  where not exists (
    select 1 from public.students st
    join public.sport_memberships sm on sm.student_id = st.id
    where st.id = requested.student_id and st.active = true and sm.sport_id = p_sport_id
  );
  if v_invalid_count > 0 then raise exception 'Attendance list contains students outside the selected sport'; end if;

  if p_present_student_ids is null then p_present_student_ids := array[]::uuid[]; end if;
  if exists (
    select 1 from unnest(p_present_student_ids) present(student_id)
    where not (present.student_id = any(p_all_student_ids))
  ) then raise exception 'Present list contains a student outside the attendance list'; end if;

  insert into public.attendance_sessions(sport_id, attendance_date)
  values(p_sport_id, p_attendance_date)
  on conflict(sport_id, attendance_date)
  do update set attendance_date = excluded.attendance_date
  returning id into v_session_id;

  delete from public.attendance_records
  where session_id = v_session_id and not (student_id = any(p_all_student_ids));

  insert into public.attendance_records(session_id, student_id, status, marked_at)
  select v_session_id, requested.student_id,
         case when requested.student_id = any(p_present_student_ids) then 'present' else 'absent' end,
         now()
  from unnest(p_all_student_ids) requested(student_id)
  on conflict(session_id, student_id)
  do update set status = excluded.status, marked_at = now();

  return v_session_id;
end;
$$;
revoke all on function public.teacher_save_attendance(uuid,date,uuid[],uuid[]) from public, anon;
grant execute on function public.teacher_save_attendance(uuid,date,uuid[],uuid[]) to authenticated;

-- Ensure teacher requests exist and are not publicly readable.
create table if not exists public.teacher_requests (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  email text not null,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  requested_at timestamptz not null default now(),
  reviewed_at timestamptz
);
alter table public.teacher_requests enable row level security;
revoke all on public.teacher_requests from anon, public;
grant insert on public.teacher_requests to authenticated;
drop policy if exists "Anyone can submit teacher access request" on public.teacher_requests;
drop policy if exists "Authenticated users can submit teacher access request" on public.teacher_requests;
create policy "Authenticated users can submit teacher access request"
on public.teacher_requests for insert to authenticated with check (status = 'pending');
