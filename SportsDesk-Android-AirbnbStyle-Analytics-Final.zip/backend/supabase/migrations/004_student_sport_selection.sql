-- Student/sport participation support.
-- Run this migration once after the existing attendance/auth migrations.

alter table public.students
  add column if not exists auth_user_id uuid references auth.users(id) on delete set null;

create unique index if not exists students_auth_user_id_unique
  on public.students(auth_user_id)
  where auth_user_id is not null;

create unique index if not exists sports_name_unique_ci
  on public.sports(lower(name));

-- Students may create/update only their own student record.
drop policy if exists "Students can create own student record" on public.students;
create policy "Students can create own student record"
on public.students
for insert to authenticated
with check (auth_user_id = (select auth.uid()));

drop policy if exists "Students can update own student record" on public.students;
create policy "Students can update own student record"
on public.students
for update to authenticated
using (auth_user_id = (select auth.uid()))
with check (auth_user_id = (select auth.uid()));

-- Students can choose multiple active sports.
drop policy if exists "Students can join own sports" on public.sport_memberships;
create policy "Students can join own sports"
on public.sport_memberships
for insert to authenticated
with check (
  student_id in (
    select p.student_id from public.profiles p
    where p.id = (select auth.uid()) and p.role = 'student'
  )
  and exists (
    select 1 from public.sports s
    where s.id = sport_id and s.active = true
  )
);

drop policy if exists "Students can leave own sports" on public.sport_memberships;
create policy "Students can leave own sports"
on public.sport_memberships
for delete to authenticated
using (
  student_id in (
    select p.student_id from public.profiles p
    where p.id = (select auth.uid()) and p.role = 'student'
  )
);

-- The teacher can add sports through the Android UI via the existing
-- "Teachers can manage sports" policy.
