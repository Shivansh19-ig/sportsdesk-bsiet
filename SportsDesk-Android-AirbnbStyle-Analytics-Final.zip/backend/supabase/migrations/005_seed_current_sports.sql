-- Current BSIET SportsDesk starter catalog.
-- Safe to run on an existing database: duplicates by name are ignored.
insert into public.sports (name, emoji, active)
values
  ('Football', '⚽', true),
  ('Cricket', '🏏', true),
  ('Basketball', '🏀', true),
  ('Athletics', '🏃', true),
  ('Volleyball', '🏐', true),
  ('Kabaddi', '🤼', true),
  ('Badminton', '🏸', true),
  ('Table Tennis', '🏓', true),
  ('Chess', '♟️', true),
  ('Kho-Kho', '🏃‍♂️', true)
on conflict (lower(name)) do update set
  emoji = excluded.emoji,
  active = true;
