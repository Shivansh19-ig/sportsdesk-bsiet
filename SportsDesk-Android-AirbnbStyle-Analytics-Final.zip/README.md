# SportsDesk — College Sports Attendance

Android Studio + Kotlin + Jetpack Compose app for college sports attendance, sport enrollment, records and analytics.

## Core workflow

Teacher Login → Dashboard → Sport → Take Attendance → Save → Records / Analytics.

Student Login → Student setup → Multi-sport selection → View profile and selected sports.

## Design direction

The UI follows the supplied design reference's visual direction: clean light canvas, near-black type, a restrained coral primary action, soft borders, generous whitespace, rounded cards, pill buttons and a focused mobile information hierarchy. Day/night mode remains available for the Android app.

The supplied football/TV reference is recreated as an original vector SportsDesk mark for crisp scaling and launcher use; the watermarked source image is not embedded in the app.

## Attendance

- Dynamic sports loaded from Supabase.
- Teacher can add sports.
- Students can participate in multiple sports.
- Teacher roster is sorted by roll number.
- Search by student name or roll number.
- All present / all absent shortcuts.
- Attendance date picker with future-date protection.
- Each sport has one attendance session per date.
- Each session contains one `present` / `absent` record per roster student.
- Attendance writes use a database transaction through `teacher_save_attendance`.

## Records

Teacher → Sport → Records shows saved sessions newest-first.

Each selected date has:
- Present count
- Absent count
- Total marked
- Separate PRESENT and ABSENT sections
- Roll-number ordering
- Search and All / Present / Absent filters

## Analytics

Teacher → Sport → Analytics provides:
- Overall attendance percentage
- Session count
- Student count
- Total present / absent marks
- Monthly calendar
- Per-day present/total markers
- Selected-day Present and Absent rosters
- Student-wise attendance percentage
- Student search

## Security/database

The database uses Supabase Auth + PostgreSQL + RLS. Teacher/student authorization is enforced server-side.

Atomic database operations handle:
- student onboarding
- multi-sport replacement
- teacher attendance saving

Important migrations are kept under `backend/supabase/migrations/`.

## Project layout

- `android/` — Android app
- `backend/` — Supabase migrations/functions
- `docs/` — architecture, security and UI documentation

## Configuration

Put Supabase credentials in `android/local.properties`:

```properties
SUPABASE_URL=YOUR_SUPABASE_URL
SUPABASE_PUBLISHABLE_KEY=YOUR_SUPABASE_PUBLISHABLE_KEY
```

The Android app reads these through `BuildConfig`. Never place a secret/service-role key in the Android client.
