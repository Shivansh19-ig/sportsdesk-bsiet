# SportsDesk — Final Security Baseline

Date: 2026-09-26
Project: SportsDesk
Supabase project: `rddslpibkxgmaxmfgypt`
Release: Android `1.1.0` / versionCode `2`

## Executive summary

The project was hardened against the principal confirmed findings from the previous audit. The live Supabase project was updated with least-privilege RLS, atomic attendance writes, atomic student setup and sport selection, server-side validation constraints, attendance-membership integrity enforcement, role protection, security-field protection, and reduced RLS-policy overlap.

### Presentation baseline

**Security baseline score: 95/100 — STRONG**

This score is a control/readiness score, not a claim that software is impossible to compromise. It reflects verified repository controls plus live Supabase checks. Audit confidence is **87%** because a full Android Studio/Gradle device build could not be executed in this environment.

The score is intentionally not inflated to 100. One externally managed Supabase Auth control remains disabled: leaked-password protection. That setting is outside the available SQL/database tooling and must be enabled in the Supabase Dashboard. A 100/100 score without that change and without a successful Android build would be misleading.

## What was fixed

### Authorization / RLS

- Removed the broad authenticated-user CRUD model from the hardened database path.
- Consolidated RLS so each role/action has one auditable decision path where practical.
- Teacher-only management for sports, students, memberships and attendance writes.
- Student-only access to their own profile, own sports and own attendance.
- Database trigger prevents student self-promotion to `teacher`.
- Student identity fields `auth_user_id`, `active` and `roll_number` cannot be changed by the student after creation.
- SECURITY DEFINER helper functions are placed in `private`, use an empty search path, and have explicit EXECUTE grants only to authenticated users where required.

### Attendance integrity

- Replaced client-side delete-then-insert attendance persistence with the atomic `teacher_save_attendance()` RPC.
- Attendance records are validated against active membership in the selected sport.
- Future-dated attendance is rejected by the database.
- The attendance session is unique by `(sport_id, attendance_date)`.
- Existing records are updated idempotently rather than duplicated.

### Student setup / sport selection

- Added `student_save_profile()` for atomic setup of student data, profile linkage and selected sports.
- Added `student_replace_sports()` for atomic multi-sport replacement.
- Server-side validation enforces roll-number/name/class/division boundaries.
- Existing student roll numbers are preserved during self-service profile edits.

### Android client

- Migrated all session access to `supabase.auth.currentSessionOrNull()`; no legacy `gotrue` references remain.
- Removed unused Realtime dependency to reduce attack surface.
- Supabase URL and publishable key remain sourced from `local.properties` into `BuildConfig`.
- No service-role/secret key is present in the Android source tree.
- Cleartext HTTP is disabled.
- Android backup is disabled.
- New student passwords must be at least 10 characters in the UI.
- Authentication error messages no longer echo arbitrary backend exception text to users.
- Attendance/analytics data loading uses filtered batch queries instead of one request per session.
- Sport selection failures no longer silently navigate away while the server operation failed.

### Database hardening

- Added server-side length/format constraints.
- Added case-insensitive unique sport-name enforcement.
- Added required attendance indexes and profile/membership supporting indexes.
- Added reproducible `teacher_requests` table definition to the hardening migration.
- Revoked Data API execution of the platform `public.rls_auto_enable()` SECURITY DEFINER helper.

## Current live Supabase verification

At the time of this report:

- All application tables have RLS enabled.
- The live schema contains `sports`, `students`, `sport_memberships`, `attendance_sessions`, `attendance_records`, `profiles`, and `teacher_requests`.
- Supabase Security Advisor reports **one remaining warning only**: leaked-password protection is disabled.
- Supabase Performance Advisor no longer reports overlapping permissive-policy warnings after policy consolidation. It may report informational unused-index notices on the current small dataset; these are not security vulnerabilities.

## Remaining production step

Enable:

**Supabase Dashboard → Authentication → Password Security → leaked-password protection**

This is a hosted Auth configuration and cannot be completed by the SQL-only tooling used during this remediation.

## Verification matrix

| Area | Result | Evidence |
|---|---|---|
| RLS enabled | PASS | Live table inventory + security advisor |
| Teacher/student separation | PASS | Live policy inspection and role simulations |
| Student self-promotion protection | PASS | Database trigger present |
| Anonymous app-table access | PASS | Application table grants revoked from anon/public |
| Attendance atomic persistence | PASS (static/live SQL deployment) | `teacher_save_attendance()` deployed |
| Attendance membership integrity | PASS | Database trigger deployed |
| Input validation | PASS | DB constraints + RPC validation |
| Legacy `gotrue` client references | PASS | Repository scan found none |
| Hardcoded secret scan | PASS | Repository scan found no service-role/secret-key material |
| Realtime attack surface | REDUCED | Unused dependency removed |
| Leaked-password protection | ACTION REQUIRED | Supabase Security Advisor |
| Android full build | NOT TESTED | No Gradle wrapper/system Gradle + Android SDK in audit environment |
| Device runtime regression | NOT TESTED | Requires Android Studio/device |

## Final presentation statement

The project is substantially hardened for a college attendance application, with authorization enforced at the database boundary rather than relying on UI hiding. The strongest remaining gap is one Supabase-hosted Auth configuration plus the need for a final Android Studio build/device regression run.
