# SportsDesk Security Remediation Report

Date: 2026-09-26
Project: SportsDesk / Supabase `rddslpibkxgmaxmfgypt`
Status: Approved remediation executed.

## What was fixed

- **SEC-001 — Fresh-deployment RLS overreach:** removed the authenticated-wide CRUD policies from the initial schema migration and added least-privilege teacher/student policies.
- **SEC-002 — Student-to-teacher escalation:** role changes are blocked by a database trigger in the base profile migration and the hardening migration.
- **SEC-003 — Ktor 3.0.3:** upgraded the Android client to Ktor 3.6.0.
- **SEC-004 — Kotlin 2.2.21:** upgraded the Kotlin Android/Compose/serialization plugins to Kotlin 2.4.20.
- **SEC-005 — `rls_auto_enable()` SECURITY DEFINER exposure:** execution was revoked from `PUBLIC`, `anon`, and `authenticated` in the live Supabase project and in the shipped hardening migration.
- **SEC-006 — Attendance delete-then-insert:** replaced it with an idempotent bulk upsert keyed by `(session_id, student_id)`, preserving historical rows and avoiding an empty-session state when a second request fails.
- **SEC-007 — Analytics N+1 request fan-out:** analytics now loads all attendance records for the selected sessions in one filtered query instead of one request per session.
- **SEC-008 — Anonymous teacher-request spam:** the source migration now allows teacher-request creation only for authenticated users.
- **SEC-009 — Hardcoded client configuration:** the Supabase URL and publishable key are read from `local.properties` into `BuildConfig` again; no client secret/service-role key is present in the source.
- **Additional mobile hardening:** Android backup is disabled for the app and cleartext HTTP is explicitly disabled.
- **Additional database performance hardening:** added an index on `profiles.student_id`.

## Live verification

The Supabase security advisor was re-run after remediation. The previous `public.rls_auto_enable()` findings are gone. One Auth configuration warning remains: **leaked-password protection is disabled**.

The live RLS model was also checked with authenticated-role simulations. A teacher session can see the student list, while a student session only sees its own student row and own sport memberships.

The live project has the remediation migrations applied as:

- `security_hardening_20260926`
- `profiles_student_index`

## Remaining action

Supabase leaked-password protection is a hosted Auth setting, not a Postgres migration. Supabase documents it under the project's Auth/password settings. Enable it in the Dashboard before production. Supabase uses the HaveIBeenPwned Pwned Passwords API for this protection. See the current documentation: https://supabase.com/docs/guides/auth/password-security

## Verification limitations

A clean Android Gradle build was not executed in this environment because the supplied project ZIP does not contain a Gradle wrapper and no system Gradle installation is available here. The source changes were statically checked, and dependency versions were checked against current vendor documentation. A device/runtime regression pass remains necessary in Android Studio.

The app's product/UI redesign and the supplied logo asset were intentionally left for the next phase because the explicit request was to remediate the security findings first.
