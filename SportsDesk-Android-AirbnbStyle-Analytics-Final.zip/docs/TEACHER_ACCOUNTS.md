# Teacher account flow

## Current safe workflow

Teachers do not self-promote to `role = teacher`.

1. The sports administrator creates the teacher in Supabase Authentication → Users.
2. The existing database trigger creates `public.profiles` with `role = student`.
3. The administrator changes that specific profile to `role = teacher`.
4. The teacher uses the separate Teacher Login in the Android app.
5. The Android app checks `profiles.role` after authentication. A non-teacher cannot enter the Teacher Dashboard.

## Optional request workflow

`backend/supabase/migrations/003_teacher_requests.sql` adds a teacher-access request table. It only stores a request; it does not grant teacher permissions. An admin workflow can later approve the request and provision the account.

## Passwords

Passwords are handled by Supabase Auth. Never add a plaintext `password` column to `profiles` or any public table.

## BSIET branding

The app currently uses a clean BSIET wordmark/lettermark. It is not presented as the official college crest. Replace the composable with the official approved logo asset when you have it.
