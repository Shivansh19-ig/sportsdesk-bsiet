# SportsDesk Security Hardening

This project uses Supabase Auth + Postgres RLS as the authorization boundary.

## Database protections

- Broad authenticated-wide CRUD policies are removed by migration `008_security_hardening.sql`.
- Teacher-only write access is enforced through `private.is_teacher()`.
- Students can access only their own student record, memberships, profile, and attendance rows.
- Profile roles are protected by a database trigger; the Android client cannot self-promote a student to teacher.
- Student account links and active status are protected from student-side changes.
- `public.rls_auto_enable()` is no longer executable through the Data API.
- Attendance writes use idempotent upsert semantics instead of delete-then-insert replacement.

## Authentication dashboard setting

Supabase's leaked-password protection is an Auth dashboard setting rather than a SQL migration. In the Supabase Dashboard for the Sportsdesk project, enable the leaked-password protection option under Authentication/password security before production deployment.

## Client configuration

The Android application reads `SUPABASE_URL` and `SUPABASE_PUBLISHABLE_KEY` from `local.properties` into `BuildConfig`. Never place a Supabase secret/service-role key in the Android app.
