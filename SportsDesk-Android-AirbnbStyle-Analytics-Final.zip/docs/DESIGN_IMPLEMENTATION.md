# SportsDesk UI refresh

SportsDesk now uses the supplied design reference as a visual direction: white/light canvas, near-black text, a restrained coral accent, generous whitespace, rounded surfaces, pill actions, and compact card grids. The implementation keeps day/night mode for the Android app and uses an original SportsDesk sports logo drawn as a vector rather than shipping the watermarked reference image.

## Primary screens
- Role picker and login
- Teacher dashboard
- Take attendance
- Attendance Records
- Analytics + monthly calendar
- Student attendance summary
- Student profile/sport selection

## Attendance workflow
Teacher -> Sport -> Take Attendance -> Save Attendance -> Records / Analytics.

Records are stored per sport and date and displayed in roll-number order with Present and Absent sections.

Analytics combines all saved sessions for a sport and provides:
- overall percentage
- session totals
- present/absent totals
- month calendar with per-day present/total markers
- selected-day Present/Absent roster
- student-wise attendance percentage and search

## Brand
The provided sports/TV/football concept is recreated as an original vector mark for clean scaling and Android launcher usage. The supplied Shutterstock-watermarked image is used only as a visual reference and is not embedded in the app.
