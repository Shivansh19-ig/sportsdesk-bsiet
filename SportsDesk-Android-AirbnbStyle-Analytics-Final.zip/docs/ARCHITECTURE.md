# SportsDesk architecture

## Android
`android/app/src/main/java/com/sportsdesk/`
- `MainActivity.kt` — app entry point
- `data/` — Supabase client, repositories and models
- `ui/` — Compose screens and theme
- `navigation/` — navigation
- `util/` — small utilities

## Backend
`backend/`
- `supabase/migrations/` — database schema and RLS policies
- `supabase/functions/` — future privileged server-side operations

The Android client talks directly to Supabase using the publishable key and RLS.
Secret/service-role credentials belong only in trusted server-side code.

## Planned production additions
- PDF generation/export
- CSV export
- Realtime attendance updates
- Teacher/admin roles
- Student import from CSV
- Backup and audit history
