# SportsDesk Release Checklist

## Before demo/presentation

1. Enable Supabase leaked-password protection.
2. Open the Android project in Android Studio.
3. Sync Gradle with the included Kotlin 2.4.20 / Android Gradle Plugin 8.13.0 configuration.
4. Confirm `local.properties` contains the SportsDesk Supabase URL and publishable key only.
5. Build `debug` and run on a physical Android device.
6. Verify teacher login and student login separately.
7. Create/select multiple sports for a student.
8. Take attendance for a sport.
9. Save attendance and open Records.
10. Open Analytics and verify date-wise, student-wise, present/absent counts.
11. Test Android back navigation from Attendance → Records → Analytics → Dashboard.
12. Do one edit-and-save attendance pass to verify the atomic upsert flow.
