# Authentication

SportsDesk has two separate login screens:

1. Teacher Login
2. Student Login

Both use Supabase Auth email/password authentication.

The password field has a show/hide control.

## Authorization

The database profile has:
- `role = teacher`
- `role = student`

Newly created accounts default to `student`.

The Android app must never allow a user to promote themselves to teacher.

Teacher accounts should be provisioned by an administrator or trusted server-side process.

## Supabase dashboard

Enable Email/Password under Authentication → Providers.

Hosted Supabase projects may require email confirmation before password login succeeds.

## Password security

Passwords are handled by Supabase Auth. Never create a public table containing plaintext passwords and never store passwords in `profiles`.
