# Dynamic sports and student participation

The app no longer hard-codes a sports list or fake dashboard counts.

## Teacher

1. Log in through Teacher Login.
2. Dashboard loads active sports directly from `public.sports`.
3. Tap **Add sport**.
4. Enter the sport name and an emoji/icon.
5. The row is inserted into Supabase.
6. Students immediately see the new active sport in their selection list after refreshing/reopening the screen.
7. Tapping a sport opens attendance for that sport.

## Student

1. Log in through Student Login.
2. First-time students complete roll number, class and division.
3. The app loads all active sports from Supabase.
4. The student can check multiple sports at the same time.
5. The selections are stored as rows in `public.sport_memberships`.
6. The student can edit the selection later.

This many-to-many relationship means one student can participate in Football + Athletics + Basketball, while another student can select only Cricket.


## Included sports
The starter database includes Football, Cricket, Basketball, Athletics, Volleyball, Kabaddi, Badminton, Table Tennis, Chess, and Kho-Kho. Teachers can add more sports from the app.
